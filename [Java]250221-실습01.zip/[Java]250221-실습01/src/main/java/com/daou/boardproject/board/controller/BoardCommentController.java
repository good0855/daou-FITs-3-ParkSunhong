package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.dto.CommentRequestDTO;
import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;
import com.daou.boardproject.board.vo.CommentVO;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

@WebServlet(value="/board/comment")
public class BoardCommentController extends HttpServlet {

    private static BoardService boardService = BoardServiceImpl.getInstance();

    // 댓글 등록 및 최신화
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int boardId = Integer.parseInt(req.getParameter("boardId"));
        int memberId = Integer.parseInt(req.getParameter("memberId"));
        String commentText = req.getParameter("commentText");

        // DTO 객체 생성
        CommentRequestDTO commentRequestDTO = new CommentRequestDTO(boardId, memberId, commentText);
        List<CommentVO> comments = boardService.addComment(commentRequestDTO);

        // JSON 응답 생성
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        // 댓글 리스트를 JSON 형식으로 변환
        StringBuilder commentsJson = new StringBuilder();
        commentsJson.append("[");
        for (int i = 0; i < comments.size(); i++) {
            CommentVO comment = comments.get(i);
            commentsJson.append(String.format(
                    "{\"boardId\": %d, \"memberId\": %d, \"commentId\": %d, \"commentText\": \"%s\", \"createdAt\": \"%s\", \"updatedAt\": \"%s\"}",
                    comment.getBoardId(), comment.getMemberId(), comment.getCommentId(),
                    comment.getCommentText(), comment.getCreatedAt().toString(),
                    comment.getUpdatedAt().toString()
            ));
            if (i < comments.size() - 1) {
                commentsJson.append(", ");
            }
        }
        commentsJson.append("]");

        // JSON 응답 반환
        String jsonResponse = String.format("{\"comments\": %s}", commentsJson.toString());
        resp.getWriter().write(jsonResponse);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 요청 본문을 읽어오기
        BufferedReader reader = req.getReader();
        StringBuilder jsonBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            jsonBuilder.append(line);
        }
        reader.close();

        // JSON 파싱 (Gson 사용)
        Gson gson = new Gson();
        // commentId와 memberId를 직접 받는다
        JsonObject jsonObject = gson.fromJson(jsonBuilder.toString(), JsonObject.class);
        int commentId = jsonObject.get("commentId").getAsInt();

        boolean isDeleted = boardService.deleteComment(commentId) == 1;

        // JSON 응답 반환
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write("{\"success\": " + isDeleted + "}");
    }
}
