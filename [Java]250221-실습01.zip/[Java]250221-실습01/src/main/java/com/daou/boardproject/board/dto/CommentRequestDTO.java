package com.daou.boardproject.board.dto;

public class CommentRequestDTO {
    private int boardId;
    private int memberId;
    private String commentText;

    public CommentRequestDTO() {
    }

    public CommentRequestDTO(int boardId, int memberId, String commentText) {
        this.boardId = boardId;
        this.memberId = memberId;
        this.commentText = commentText;
    }

    public int getBoardId() {
        return boardId;
    }

    public void setBoardId(int boardId) {
        this.boardId = boardId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getCommentText() {
        return commentText;
    }

    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }

    @Override
    public String toString() {
        return "CommentRequestDTO{" +
                "boardId=" + boardId +
                ", memberId=" + memberId +
                ", commentText='" + commentText + '\'' +
                '}';
    }
}
