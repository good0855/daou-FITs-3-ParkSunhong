package com.daou.boardproject.board.vo;

import java.time.LocalDateTime;

public class BoardVO {
    private int boardId;
    private int memberId;
    private String nickname;
    private String title;
    private int viewCount;
    private int likeCount;
    private int commentCount;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public BoardVO(int boardId, int memberId, String nickname, String title, int viewCount, int likeCount, int commentCount, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.boardId = boardId;
        this.memberId = memberId;
        this.nickname = nickname;
        this.title = title;
        this.viewCount = viewCount;
        this.likeCount = likeCount;
        this.commentCount = commentCount;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getBoardId() {
        return boardId;
    }

    public int getMemberId() {
        return memberId;
    }

    public String getNickname() {
        return nickname;
    }

    public String getTitle() {
        return title;
    }

    public int getViewCount() {
        return viewCount;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public String toString() {
        return "BoardVO{" +
                "boardId=" + boardId +
                ", memberId=" + memberId +
                ", nickname='" + nickname + '\'' +
                ", title='" + title + '\'' +
                ", viewCount=" + viewCount +
                ", likeCount=" + likeCount +
                ", commentCount=" + commentCount +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}