package com.daou.boardproject.board.dto;

public class BoardUpdateRequestDTO {
    private int boardId;
    private int memberId;
    private String title;
    private String content;

    BoardUpdateRequestDTO() {}

    public BoardUpdateRequestDTO(int boardId, int memberId, String title, String content) {
        this.boardId = boardId;
        this.memberId = memberId;
        this.title = title;
        this.content = content;
    }

    public int getBoardId() {
        return boardId;
    }

    public void setBoardId(int boardId) {
        this.boardId = boardId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "BoardUpdateRequestDTO{" +
                "boardId=" + boardId +
                ", memberId=" + memberId +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
