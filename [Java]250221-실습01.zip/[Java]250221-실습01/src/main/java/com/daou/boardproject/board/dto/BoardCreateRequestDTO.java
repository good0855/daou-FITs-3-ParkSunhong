package com.daou.boardproject.board.dto;

public class BoardCreateRequestDTO {
    private int memberId;
    private String title;
    private String content;

    public BoardCreateRequestDTO() {}

    public BoardCreateRequestDTO(int memberId, String title, String content) {
        this.memberId = memberId;
        this.title = title;
        this.content = content;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "BoardCreateRequestDTO{" +
                "memberId=" + memberId +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
