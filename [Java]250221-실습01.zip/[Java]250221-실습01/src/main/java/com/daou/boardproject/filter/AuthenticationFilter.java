package com.daou.boardproject.filter;

import com.daou.boardproject.member.vo.MemberVO;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

// 특정 url로부터 로그인 인증되었나 filter 하는 로직
public class AuthenticationFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("AuthenticationFilter init");
        Filter.super.init(filterConfig);
    }

    @Override
    public void destroy() {
        System.out.println("AuthenticationFilter destroy");
        Filter.super.destroy();
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        System.out.println("AuthenticationFilter doFilter");
        // HttpServletRequest로 캐스팅
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;

        // 세션에서 유저 정보 가져오기
        HttpSession session = request.getSession(false); // 세션이 없으면 null 반환
        MemberVO member = (session != null) ? (MemberVO) session.getAttribute("member") : null;

        if (member == null) {
            // 로그인 안 된 상태면 로그인 페이지나 에러 페이지로 리다이렉트
            response.sendRedirect("/BoardProject/login"); // 로그인 페이지 경로에 맞게 수정
            return;
        }

        // 유저 ID 가져오기
        String memberIdStr = String.valueOf(member.getMemberId());

        // 다음 필터 실행
        chain.doFilter(req, resp);
    }
}
