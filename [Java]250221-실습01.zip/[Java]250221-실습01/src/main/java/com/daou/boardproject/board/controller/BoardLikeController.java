package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.dto.LikeToggleDTO;
import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;
import com.daou.boardproject.board.vo.LikeListVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

//@WebServlet(value="/board/like")
//public class BoardLikeController extends HttpServlet {
//    private final BoardService boardService = BoardServiceImpl.getInstance();
//
//    @Override
//    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        System.out.println("boardLikeController doPost");
//
//        int boardId = Integer.parseInt(req.getParameter("boardId"));
//        int memberId = Integer.parseInt(req.getParameter("memberId"));
//
//        LikeToggleDTO likeToggleDTO = new LikeToggleDTO(boardId, memberId);
//
//
//        // 서버에서 좋아요 상태 및 유저 목록 확인
//        HashMap<String, Object> map = boardService.likeToggle(likeToggleDTO); // 1이면 true 0이면
//        boolean isLiked = (int) map.get("result") == 1; // 1이면 true 0이면 false
//        List<LikeListVO> likes = (List<LikeListVO>) map.get("likes");
//        int likeCount = likes.size();
//
////        int likeCount = boardService.getLikeCount(boardId); // 해당 게시글의 좋아요 수
////        int likeCount = 0;
//
//        // JSON 응답 생성
//        resp.setContentType("application/json");
//        resp.setCharacterEncoding("UTF-8");
//
//        // JSON 응답을 작성하여 반환
//        String jsonResponse = String.format("{\"isLiked\": %b, \"likeCount\": %d}", isLiked, likeCount);
//        resp.getWriter().write(jsonResponse);
//    }
//
//}
@WebServlet(value="/board/like")
public class BoardLikeController extends HttpServlet {
    private final BoardService boardService = BoardServiceImpl.getInstance();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("boardLikeController doPost");

        int boardId = Integer.parseInt(req.getParameter("boardId"));
        int memberId = Integer.parseInt(req.getParameter("memberId"));

        LikeToggleDTO likeToggleDTO = new LikeToggleDTO(boardId, memberId);

        // 서버에서 좋아요 상태 및 유저 목록 확인
        HashMap<String, Object> map = boardService.likeToggle(likeToggleDTO);
        boolean isLiked = (int) map.get("result") == 0; // 0이면 true 0이면 false
        List<LikeListVO> likes = (List<LikeListVO>) map.get("likes");
        int likeCount = likes.size();

        // JSON 응답 생성
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        // 좋아요 누른 사람 리스트 JSON 변환
        StringBuilder likesJson = new StringBuilder();
        likesJson.append("[");
        for (int i = 0; i < likes.size(); i++) {
            LikeListVO like = likes.get(i);
            likesJson.append(String.format(
                    "{\"boardId\": %d, \"memberId\": %d, \"nickname\": \"%s\", \"createdAt\": \"%s\"}",
                    like.getBoardId(), like.getMemberId(), like.getNickname(), like.getCreatedAt().toString()
            ));
            if (i < likes.size() - 1) {
                likesJson.append(", ");
            }
        }
        likesJson.append("]");

        // JSON 응답을 작성하여 반환
        String jsonResponse = String.format("{\"isLiked\": %b, \"likeCount\": %d, \"likes\": %s}", isLiked, likeCount, likesJson.toString());
        resp.getWriter().write(jsonResponse);
    }
}
