package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;
import com.daou.boardproject.board.vo.BoardVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(value = "/board/search")
public class BoardSearchController extends HttpServlet {
    private static BoardService boardService = BoardServiceImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 검색어와 검색 기준 파라미터 가져오기
        String titleKeyword = req.getParameter("titleKeyword");
        String searchType = req.getParameter("searchType");

        List<BoardVO> contents = null;
        System.out.println("keyword "  + titleKeyword);

        // 검색 기준에 따라 분기
        if ("title".equals(searchType)) {
            contents = boardService.searchContentByTitle(titleKeyword);
        } else if ("content".equals(searchType)) {
            contents = boardService.searchContentByContent(titleKeyword);
        }

        // 검색 결과를 request에 저장하여 JSP로 전달
        req.setAttribute("contents", contents);

        // 검색된 게시글 목록이 담긴 boardMain.jsp로 포워딩
        req.getRequestDispatcher("/board/boardMain.jsp").forward(req, resp);
    }
}
