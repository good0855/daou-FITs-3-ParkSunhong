package com.daou.boardproject.board.vo;

import java.time.LocalDateTime;

public class LikeListVO {
    private int boardId;
    private int memberId;
    private String nickname;
    private LocalDateTime createdAt;

    public LikeListVO() {
    }

    public LikeListVO(int boardId, int memberId, String nickname, LocalDateTime createdAt) {
        this.boardId = boardId;
        this.memberId = memberId;
        this.nickname = nickname;
        this.createdAt = createdAt;
    }

    public int getBoardId() {
        return boardId;
    }

    public int getMemberId() {
        return memberId;
    }

    public String getNickname() {
        return nickname;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    @Override
    public String toString() {
        return "LikeListVO{" +
                "boardId=" + boardId +
                ", memberId=" + memberId +
                ", nickname='" + nickname + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
