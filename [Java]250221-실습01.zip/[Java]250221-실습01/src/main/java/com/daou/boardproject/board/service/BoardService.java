package com.daou.boardproject.board.service;

import com.daou.boardproject.board.dto.BoardCreateRequestDTO;
import com.daou.boardproject.board.dto.BoardUpdateRequestDTO;
import com.daou.boardproject.board.dto.CommentRequestDTO;
import com.daou.boardproject.board.dto.LikeToggleDTO;
import com.daou.boardproject.board.vo.BoardVO;
import com.daou.boardproject.board.vo.CommentVO;

import java.util.HashMap;
import java.util.List;

public interface BoardService {
    // 모든 글 보여주기
    List<BoardVO> showAllContent();
    // 특정 글 보여주기
    HashMap<String, Object> showOneContent(int boardId);
    // 글 등록
    int addBoard(BoardCreateRequestDTO boardCreateRequestDTO);
    // 글 삭제
    int deleteBoard(int boardId);
    // 글 수정
    int updateBoard(BoardUpdateRequestDTO boardUpdateRequestDTO);
    // 댓글 등록
    List<CommentVO> addComment(CommentRequestDTO commentRequestDTO);
    // 댓글 삭제
    int deleteComment(int commentId);
    // 좋아요 토글
    HashMap<String, Object> likeToggle(LikeToggleDTO likeToggleDTO);
    // 타이틀 기반 검색
    List<BoardVO> searchContentByTitle(String titleKeyword);
    // 본문 기반 검색
    List<BoardVO> searchContentByContent(String contentKeyword);

    }

