package com.daou.boardproject.board.vo;

import java.time.LocalDateTime;

public class CommentVO {
    private int boardId;
    private int memberId;
    private int commentId;
    private String commentText;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public CommentVO() {}

    public CommentVO(int boardId, int memberId, int commentId, String commentText, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.boardId = boardId;
        this.memberId = memberId;
        this.commentId = commentId;
        this.commentText = commentText;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getBoardId() {
        return boardId;
    }

    public int getMemberId() {
        return memberId;
    }

    public int getCommentId() {
        return commentId;
    }

    public String getCommentText() {
        return commentText;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    @Override
    public String toString() {
        return "CommentVO{" +
                "boardId=" + boardId +
                ", memberId=" + memberId +
                ", commentId=" + commentId +
                ", commentText='" + commentText + '\'' +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}
