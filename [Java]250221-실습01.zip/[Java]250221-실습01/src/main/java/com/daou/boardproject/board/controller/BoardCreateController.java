package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.dto.BoardCreateRequestDTO;
import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;
import com.daou.boardproject.member.vo.MemberVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(value="/board/create")
public class BoardCreateController extends HttpServlet {

    private final BoardService boardService = BoardServiceImpl.getInstance();

    // 게시글 등록
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("BoardCreateController doGet");
        req.getRequestDispatcher("/board/boardCreate.jsp").forward(req, resp);
    }

    // 게시글 등록
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        // 세션에서 로그인한 사용자 ID 가져오기

        HttpSession session = req.getSession();
        MemberVO member = (MemberVO) session.getAttribute("member");
        String memberIdStr = String.valueOf(member.getMemberId());

        if (memberIdStr == null) {
            resp.sendRedirect("/BoardProject/login");
            return;
        }

        int memberId = Integer.parseInt(memberIdStr);
        String title = req.getParameter("title");
        String content = req.getParameter("content");

        // DTO 생성
        BoardCreateRequestDTO boardCreateRequestDTO = new BoardCreateRequestDTO(memberId, title, content);

        // 게시글 추가
        boardService.addBoard(boardCreateRequestDTO);

        // 등록 후 메인 페이지로 이동
        resp.sendRedirect("/BoardProject/board");
    }
}
