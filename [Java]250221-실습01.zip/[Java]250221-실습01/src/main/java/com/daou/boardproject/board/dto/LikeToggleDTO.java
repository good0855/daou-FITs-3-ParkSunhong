package com.daou.boardproject.board.dto;

public class LikeToggleDTO {
    private int boardId;
    private int memberId;

    public LikeToggleDTO() {}

    public LikeToggleDTO(int boardId, int memberId) {
        this.boardId = boardId;
        this.memberId = memberId;
    }

    public int getBoardId() {
        return boardId;
    }

    public int getMemberId() {
        return memberId;
    }

    @Override
    public String toString() {
        return "LikeToggleDTO{" +
                "boardId=" + boardId +
                ", memberId=" + memberId +
                '}';
    }
}
