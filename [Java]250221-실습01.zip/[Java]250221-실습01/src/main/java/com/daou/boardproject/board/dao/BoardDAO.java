package com.daou.boardproject.board.dao;

import com.daou.boardproject.board.dto.BoardCreateRequestDTO;
import com.daou.boardproject.board.dto.BoardUpdateRequestDTO;
import com.daou.boardproject.board.dto.CommentRequestDTO;
import com.daou.boardproject.board.dto.LikeToggleDTO;
import com.daou.boardproject.board.vo.BoardDetailVO;
import com.daou.boardproject.board.vo.BoardVO;
import com.daou.boardproject.board.vo.CommentVO;
import com.daou.boardproject.board.vo.LikeListVO;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class BoardDAO {
    // 1. 모든 글 보여주기
    private static BoardDAO instance;
    // 기본 생성자 추가
    private BoardDAO() {
        // 기본 생성자
    }
    public static BoardDAO getInstance() {
        if (instance == null) {
            instance = new BoardDAO();
        }
        return instance;
    }

    private SqlSession session;

    public void setSession(SqlSession session) {
        this.session = session;
    }

    // 1. board 모든 글 보여주기
    public List<BoardVO> selectAllContent() {
        return this.session.selectList("com.daou.Board.selectAllContent");

    }

    // 2.1 특정 글 상세페이지 보여주기 모든 글 보여주기
    public BoardDetailVO selectContentByBoardId(int boardId) {
        return this.session.selectOne("com.daou.Board.selectContentByBoardId", boardId);
    }

    // 2.2 특정 글 조회수 업데이트 해주기
    public int updateContentView(int boardId) {
        return this.session.update("com.daou.Board.updateContentView", boardId);
    }

    // 3. 글 등록
    public int insertContent(BoardCreateRequestDTO boardCreateRequestDTO ) {
        return this.session.insert("com.daou.Board.insertContent", boardCreateRequestDTO);
    }

    // 4. 글 삭제
    public int deleteContent(int boardId) {
        return this.session.delete("com.daou.Board.deleteContent", boardId);
    }

    // 5. 글 수정
    public int updateContent(BoardUpdateRequestDTO boardUpdateRequestDTO) {
        return this.session.update("com.daou.Board.updateContent", boardUpdateRequestDTO);
    }

    // 6.1 댓글 조회
    public List<CommentVO> selectCommentById(int boardId) {
        return this.session.selectList("com.daou.Board.selectCommentById", boardId);
    }

    // 6.2 댓글 조회
    public int insertComment(CommentRequestDTO commentRequestDTO) {
        return this.session.insert("com.daou.Board.insertComment", commentRequestDTO);
    }

    //6.3 댓글 삭제
    public int deleteComment(int commentId) {
        return this.session.delete("com.daou.Board.deleteComment", commentId);
    }

    // 7.1 좋아요 조회
    public int selectIsLikeByMemberAndBoardId(LikeToggleDTO likeToggleDTO) {
        return this.session.selectOne("com.daou.Board.selectIsLikeByMemberAndBoardId", likeToggleDTO);
    }

    // 7.2 좋아요 취소
    public int deleteLikeByMemberAndBoardId(LikeToggleDTO likeToggleDTO) {
        return this.session.delete("com.daou.Board.deleteLikeByMemberAndBoardId", likeToggleDTO);
    }

    // 7.2 좋아요 등록
    public int insertLikeByMemberAndBoardId(LikeToggleDTO likeToggleDTO) {
        return this.session.insert("com.daou.Board.insertLikeByMemberAndBoardId", likeToggleDTO);
    }

    // 7.3 좋아요 목록 조회
    public List<LikeListVO> selectLikeMemberByBoardId(int boardId) {
        return this.session.selectList("com.daou.Board.selectLikeMemberByBoardId", boardId);
    }

    // 8.1 타이틀 기반 검색
    public List<BoardVO> selectContentByTitle(String titleKeyword) {
        return this.session.selectList("com.daou.Board.selectContentByTitle", titleKeyword);
    }

    // 8.2 본문 기반 검색
    public List<BoardVO> selectContentByContent(String contentKeyword) {
        return this.session.selectList("com.daou.Board.selectContentByContent", contentKeyword);
    }


}
