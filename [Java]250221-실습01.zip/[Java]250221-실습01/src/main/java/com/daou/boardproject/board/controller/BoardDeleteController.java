package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/board/delete")
public class BoardDeleteController extends HttpServlet {
    private final BoardService boardService = BoardServiceImpl.getInstance();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        System.out.println("BoardDeleteController doPost");

        int boardId = Integer.parseInt(req.getParameter("boardId"));
        boardService.deleteBoard(boardId);

        // 삭제 후 redirect
        resp.sendRedirect("/BoardProject/board");
    }

    @Override
    public void destroy() {
        super.destroy();
    }
}
