package com.daou.boardproject.board.service;

import com.daou.boardproject.board.dao.BoardDAO;
import com.daou.boardproject.board.dto.BoardCreateRequestDTO;
import com.daou.boardproject.board.dto.BoardUpdateRequestDTO;
import com.daou.boardproject.board.dto.CommentRequestDTO;
import com.daou.boardproject.board.dto.LikeToggleDTO;
import com.daou.boardproject.board.vo.BoardDetailVO;
import com.daou.boardproject.board.vo.BoardVO;
import com.daou.boardproject.board.vo.CommentVO;
import com.daou.boardproject.board.vo.LikeListVO;
import com.daou.boardproject.util.MyBatisSessionFactory;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class BoardServiceImpl implements BoardService {
    private static BoardService instance = new BoardServiceImpl();

    private BoardServiceImpl() {}

    public static BoardService getInstance() {
        if (instance == null) {
            instance = new BoardServiceImpl();
        }
        return instance;
    }

    private final BoardDAO boardDAO = BoardDAO.getInstance();

    // 모든 글을 가져오는 메소드
    @Override
    public List<BoardVO> showAllContent() {
        List<BoardVO> contents = null;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            contents = boardDAO.selectAllContent();
            System.out.println(contents);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return contents;
    }

    // boardId에 따라 글 + 댓글 보여주기
    @Override
    public HashMap<String, Object> showOneContent(int boardId) {
        HashMap<String, Object> map = new HashMap<>();
        BoardDetailVO content = null;
        List<CommentVO> comments = Collections.emptyList();
        List<LikeListVO> likes = Collections.emptyList();

        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            // 조회수 업데이트
            boardDAO.updateContentView(boardId);
            System.out.println("조회수 업데이트");
            // 업데이트 적용된 게시글 보여주기
            content = boardDAO.selectContentByBoardId(boardId);
            System.out.println("content: " + content);
            // 댓글 보여주기
            comments = boardDAO.selectCommentById(boardId);
            System.out.println("comments: " + comments);
            // 좋아요 개수 확인
            likes = boardDAO.selectLikeMemberByBoardId(boardId);
            System.out.println("likes: " + likes);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        // 불러온 글과 댓글 가져오기
        map.put("content", content);
        map.put("comments", comments);
        map.put("likes", likes);

        System.out.println("map: " + map);
        return map;
    }

    // 글 등록
    @Override
    public int addBoard(BoardCreateRequestDTO boardCreateRequestDTO) {
        int result = 0;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            result = boardDAO.insertContent(boardCreateRequestDTO);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return result;
    }

    // 글 삭제
    @Override
    public int deleteBoard(int boardId) {
        int result = 0;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            result = boardDAO.deleteContent(boardId);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return result;
    }

    // 글 수정
    @Override
    public int updateBoard(BoardUpdateRequestDTO boardUpdateRequestDTO) {
        int result = 0;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            result = boardDAO.updateContent(boardUpdateRequestDTO);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return result;
    }

    // 댓글 등록 기능
    @Override
    public List<CommentVO> addComment(CommentRequestDTO commentRequestDTO) {
        List<CommentVO> comments = Collections.emptyList();
        int result = 0;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            // 추가하고
            result = boardDAO.insertComment(commentRequestDTO);
            // 재조회한다.
            comments = boardDAO.selectCommentById(commentRequestDTO.getBoardId());
            System.out.println("comments: " + comments);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return comments;
    }

    // 댓글 삭제 기능
    @Override
    public int deleteComment(int commentId) {
        int result = 0;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            result = boardDAO.deleteComment(commentId);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return result;
    }

    // 좋아요 기능
    @Override
    public HashMap<String, Object> likeToggle(LikeToggleDTO likeToggleDTO) {
        HashMap<String, Object> map = new HashMap<>();
        int result = 0;
        List<LikeListVO> likes = Collections.emptyList();

        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            // 우선 좋아요가 있는지 조회한다.
            result = boardDAO.selectIsLikeByMemberAndBoardId(likeToggleDTO);
            System.out.println(result + " 좋아요 개수입니다");
            // 만약 존재한다면 좋아요 취소(DELETE)
            if (result == 1) {
                boardDAO.deleteLikeByMemberAndBoardId(likeToggleDTO);
                System.out.println("LIKE DELETE SUCCESS");
                // 존재하지 않다면 좋아요 등록(INSERT)
            } else if (result == 0) {
                boardDAO.insertLikeByMemberAndBoardId(likeToggleDTO);
                System.out.println("LIKE INSERT SUCCESS");
            }

            // 좋아요 반환
            likes = boardDAO.selectLikeMemberByBoardId(likeToggleDTO.getBoardId());

            // 결과와 좋아요 리스트 반환
            map.put("result", result);
            map.put("likes", likes);

            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return map;
    }

    @Override
    public List<BoardVO> searchContentByTitle(String titleKeyword) {
        List<BoardVO> contents = null;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            contents = boardDAO.selectContentByTitle(titleKeyword);
            System.out.println(contents);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return contents;
    }

    @Override
    public List<BoardVO> searchContentByContent(String contentKeyword) {
        List<BoardVO> contents = null;
        SqlSessionFactory factory = MyBatisSessionFactory.getSqlSessionFactory();
        SqlSession session = factory.openSession();

        boardDAO.setSession(session);

        try {
            contents = boardDAO.selectContentByContent(contentKeyword);
            System.out.println(contents);
            session.commit();

        } catch (Exception e) {
            e.printStackTrace();
            session.rollback();
        } finally {
            session.close();
        }

        return contents;
    }
}
