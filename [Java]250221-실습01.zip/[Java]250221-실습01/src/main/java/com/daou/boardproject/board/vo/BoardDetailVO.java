package com.daou.boardproject.board.vo;

import java.time.LocalDateTime;

public class BoardDetailVO extends BoardVO {
    private String content;

    // 생성자
    public BoardDetailVO(int boardId, int memberId, String nickname, String title, String content, int viewCount, int likeCount, int commentCount, LocalDateTime createdAt, LocalDateTime updatedAt) {
        super(boardId, memberId, nickname, title, viewCount, likeCount, commentCount, createdAt, updatedAt); // 부모 클래스(BoardVO)의 생성자 호출
        this.content = content; // BoardDetailVO의 content 필드 초기화
    }

    public String getContent() {
        return content;
    }

    @Override
    public String toString() {
        return "BoardDetailVO{" +
                "boardId=" + getBoardId() +
                ", memberId=" + getMemberId() +
                ", nickname='" + getNickname() + '\'' +
                ", title='" + getTitle() + '\'' +
                ", viewCount=" + getViewCount() +
                ", likeCount=" + getLikeCount() +
                ", commentCount=" + getCommentCount() +
                ", createdAt=" + getCreatedAt() +
                ", updatedAt=" + getUpdatedAt() +
                ", content='" + content + '\'' +
                '}';
    }

}
