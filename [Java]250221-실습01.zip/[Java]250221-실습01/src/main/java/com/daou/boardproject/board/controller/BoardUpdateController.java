package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.dto.BoardUpdateRequestDTO;
import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;
import com.daou.boardproject.board.vo.BoardDetailVO;
import com.daou.boardproject.board.vo.BoardVO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/board/update")
public class BoardUpdateController extends HttpServlet {
    private final BoardService boardService = BoardServiceImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("BoardUpdate doGet");
        String boardIdParam = req.getParameter("boardId");

        int boardId = Integer.parseInt(boardIdParam); // "1" -> 1

        BoardDetailVO content = (BoardDetailVO) boardService.showOneContent(boardId).get("content"); // 해당 ID의 게시글 조회

        if (content == null) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "게시글을 찾을 수 없습니다.");
            return;
        }

        // update 창으로 감
        req.setAttribute("content", content);
        req.getRequestDispatcher("/board/boardUpdate.jsp").forward(req, resp);    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 한글 깨짐 방지
        req.setCharacterEncoding("UTF-8");  // 추가해야 하는 코드 ✅
        resp.setCharacterEncoding("UTF-8");

        System.out.println("BoardUpdate doPost");
        int boardId = Integer.parseInt(req.getParameter("boardId"));
        int memberId = Integer.parseInt(req.getParameter("memberId"));
        String title = req.getParameter("title");
        String content = req.getParameter("content");

        BoardUpdateRequestDTO updateRequestDTO = new BoardUpdateRequestDTO(boardId, memberId, title, content);
        System.out.println(updateRequestDTO);
        boardService.updateBoard(updateRequestDTO);

        resp.sendRedirect("/BoardProject/board?boardId=" + boardId);

    }
}
