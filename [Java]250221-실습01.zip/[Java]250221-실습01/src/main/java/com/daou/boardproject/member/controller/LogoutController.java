package com.daou.boardproject.member.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/logout")
public class LogoutController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 세션에서 "member" 객체 제거 (로그아웃 처리)
        System.out.println("logout post");
        req.getSession().removeAttribute("member");
        req.getSession().invalidate(); // 세션을 완전히 무효화하고자 한다면 사용 (세션 전체를 지우기)

        // 로그아웃 후, 메인 페이지로
        resp.sendRedirect(req.getContextPath());
    }
}
