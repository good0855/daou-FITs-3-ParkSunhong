package com.daou.boardproject.board.controller;

import com.daou.boardproject.board.vo.CommentVO;
import com.daou.boardproject.board.vo.LikeListVO;
import com.google.gson.Gson;
import com.daou.boardproject.board.service.BoardService;
import com.daou.boardproject.board.service.BoardServiceImpl;
import com.daou.boardproject.board.vo.BoardDetailVO;
import com.daou.boardproject.board.vo.BoardVO;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;



@WebServlet(value="/board")
public class BoardController extends HttpServlet {
    private final BoardService boardService = BoardServiceImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 쿼리 문자열에서 boardId 파라미터를 가져옵니다.
        String boardIdParam = req.getParameter("boardId");

        // boardId가 없으면 전체 게시글 조회
        if (boardIdParam == null) {
            List<BoardVO> contents = boardService.showAllContent(); // 전체 게시글 조회
            req.setAttribute("contents", contents);
            req.getRequestDispatcher("/board/boardMain.jsp").forward(req, resp);
//            List<BoardVO> contents = boardService.showAllContent(); // 전체 게시글 조회
//            Gson gson = new Gson();
//            String jsonResponse = gson.toJson(contents);  // List<BoardVO>를 JSON으로 변환
//            resp.setContentType("application/json");
//            resp.setCharacterEncoding("UTF-8");
//            resp.getWriter().write(jsonResponse);  // 응답으로 JSON 데이터 반환
        } else {
            // boardId가 있을 경우 상세 게시글 조회
            try {

                int boardId = Integer.parseInt(boardIdParam); // "1" -> 1
                HashMap<String, Object> map = boardService.showOneContent(boardId); // 해당 ID의 게시글 조회

                BoardDetailVO content = (BoardDetailVO) map.get("content");
                List<CommentVO> comments = (List<CommentVO>) map.get("comments");
                List<LikeListVO> likes = (List<LikeListVO>) map.get("likes");

                req.setAttribute("content", content);
                req.setAttribute("comments", comments);
                req.setAttribute("likes", likes);
                req.getRequestDispatcher("/board/boardDetail.jsp").forward(req, resp);

//                // JSON 변환
//                HashMap<String, Object> responseMap = new HashMap<>();
//                responseMap.put("content", content);
//                responseMap.put("comments", comments);
//                responseMap.put("likes", likes);
//
//                Gson gson = new Gson();
//                String jsonResponse = gson.toJson(responseMap);  // 데이터를 JSON으로 변환
//
//                resp.setContentType("application/json");
//                resp.setCharacterEncoding("UTF-8");
//                resp.getWriter().write(jsonResponse);  // 응답으로 JSON 데이터 반환
//
//                RequestDispatcher dispatcher = req.getRequestDispatcher("/board/boardDetail.jsp");
//                dispatcher.forward(req, resp);  // JSP로 데이터 전달 및 이동

            } catch (NumberFormatException e) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "잘못된 요청입니다.");
            }
        }
    }
}



