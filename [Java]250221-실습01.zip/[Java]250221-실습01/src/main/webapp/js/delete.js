$(document).ready(function() {
    $(".delete-comment").click(function() {
        let commentId = $(this).data("comment-id");
        let memberId = $("#user-session").data("member-id"); // 세션에서 가져오기
        console.log(commentId);
        console.log(memberId);
        if (!confirm("정말 삭제하시겠습니까?")) {
            return;
        }

        $.ajax({
            url: "board/comment",
            type: "DELETE",
            contentType: "application/json",  // 요청 헤더에 JSON 형식 지정
            data: JSON.stringify({ commentId: commentId, memberId: memberId }),  // JSON 형식으로 데이터 전송
            success: function(response) {
                if (response.success) {
                    $("li[data-comment-id='" + commentId + "']").fadeOut(300, function() {
                        $(this).remove();
                    });
                } else {
                    alert("댓글 삭제 실패!");
                }
            },
            error: function() {
                alert("서버 오류가 발생했습니다.");
            }
        });
    });
});
//
// $(document).ready(function() {
//     // 삭제 버튼 클릭 이벤트
//     $(".delete-comment").click(function() {
//         let commentId = $(this).data("comment-id");
//         let memberId = $("#user-session").data("member-id");
//         if (!confirm("정말 삭제하시겠습니까?")) {
//             return;
//         }
//
//         $.ajax({
//             url: "board/comment",
//             type: "DELETE",
//             contentType: "application/json",
//             data: JSON.stringify({ commentId: commentId, memberId: memberId }),
//             success: function(response) {
//                 if (response.success) {
//                     $("div[data-comment-id='" + commentId + "']").fadeOut(300, function() {
//                         $(this).remove();
//                     });
//                 } else {
//                     alert("댓글 삭제 실패!");
//                 }
//             },
//             error: function() {
//                 alert("서버 오류가 발생했습니다.");
//             }
//         });
//     });
// });
