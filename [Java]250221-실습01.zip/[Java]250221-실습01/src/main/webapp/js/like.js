$(document).ready(function() {
    console.log("jQuery가 정상적으로 로드되었습니다.");

    // 좋아요 버튼 클릭 시
    $(".like-button").click(function(event) {
        event.preventDefault(); // 폼 제출 방지
        console.log($(this).data());

        var boardId = this.getAttribute('boardId');  // getAttribute로 직접 접근
        var memberId = this.getAttribute('memberId'); // getAttribute로 직접 접근
        console.log(boardId)
        console.log(memberId)

        // AJAX 요청
        $.ajax({
            url: "/BoardProject/board/like",
            type: "POST",
            data: {
                boardId: boardId,
                memberId: memberId
            },
            success: function(response) {
                // 응답에 따라 UI 변경 (예: 좋아요 상태 갱신)
                if (response.isLiked) {
                    // 좋아요 상태 변경
                    $(".like-button").text("좋아요 취소");
                } else {
                    $(".like-button").text("좋아요");
                }
                // 좋아요 수 갱신
                $(".like-count").text(response.likeCount);

                // 좋아요한 사람 목록 갱신
                var likesHtml = '';
                if (response.likes.length > 0) {
                    response.likes.forEach(function(like) {
                        likesHtml += `<li>${like.nickname}</li>`;
                    });
                } else {
                    likesHtml = '<li>아직 좋아요한 사람이 없습니다.</li>';
                }
                $(".like-list").html(likesHtml); // 좋아요 누른 사람들 표시
            },
            error: function(xhr, status, error) {
                console.error("좋아요 요청 실패: ", error);
            }
        });
    });
});
