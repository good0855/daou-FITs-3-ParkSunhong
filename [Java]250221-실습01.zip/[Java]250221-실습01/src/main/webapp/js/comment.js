// $(document).ready(function () {
//     console.log("댓글 기능이 정상적으로 로드되었습니다.");
//
//     // 댓글 작성 버튼 클릭 시
//     $(".comment-submit").click(function (event) {
//         event.preventDefault(); // 기본 이벤트 방지
//         console.log("댓글 작성 버튼 클릭");
//
//         var boardId = this.getAttribute('boardId');
//         var memberId = this.getAttribute('memberId');
//         var commentText = $("textarea[name='commentText']").val().trim();
//
//         if (commentText === "") {
//             alert("댓글을 입력해주세요.");
//             return;
//         }
//
//         console.log("전송 데이터: ", { boardId, memberId, commentText });
//
//         // AJAX 요청
//         $.ajax({
//             url: "/BoardProject/board/comment",
//             type: "POST",
//             data: {
//                 boardId: boardId,
//                 memberId: memberId,
//                 commentText: commentText
//             },
//             success: function (response) {
//                 console.log("댓글 추가 성공: ", response);
//
//                 var commentList = $("#comment-list");
//
//                 // 기존 댓글 리스트를 비우고 새로운 댓글을 추가
//                 commentList.empty(); // 기존 댓글 비우기
//
//                 // 새로운 댓글을 리스트에 추가
//                 response.comments.forEach(comment => {
//                     var formattedDate = new Date(comment.createdAt).toLocaleString(); // 날짜 포맷 변환
//
//                     // 새로운 댓글 HTML 추가
//                     var newCommentHtml = `
//                         <div class="content" data-comment-id="${comment.commentId}">
//                             <p><strong>작성자:</strong> ${comment.memberId}</p>
//                             <p>${comment.commentText.replace(/\n/g, "<br>")}</p>
//                             <p class="info">작성일: ${formattedDate}</p>
//                             <!-- 삭제 버튼 추가 -->
//                             <button class="delete-comment" data-comment-id="${comment.commentId}">댓글 삭제</button>
//                         </div>
//                     `;
//
//                     commentList.append(newCommentHtml);  // 댓글 리스트에 새로운 댓글 추가
//                 });
//
//                 // 삭제 버튼 클릭 이벤트 핸들러 등록
//                 $(".delete-comment").click(function () {
//                     let commentId = $(this).data("comment-id");
//                     let memberId = $("#user-session").data("member-id"); // 세션에서 가져오기
//                     console.log(commentId);
//                     console.log(memberId);
//                     if (!confirm("정말 삭제하시겠습니까?")) {
//                         return;
//                     }
//
//                     $.ajax({
//                         url: "board/comment",
//                         type: "DELETE",
//                         contentType: "application/json",  // 요청 헤더에 JSON 형식 지정
//                         data: JSON.stringify({ commentId: commentId, memberId: memberId }),  // JSON 형식으로 데이터 전송
//                         success: function(response) {
//                             if (response.success) {
//                                 $("div[data-comment-id='" + commentId + "']").fadeOut(300, function() {
//                                     $(this).remove();
//                                 });
//                             } else {
//                                 alert("댓글 삭제 실패!");
//                             }
//                         },
//                         error: function() {
//                             alert("서버 오류가 발생했습니다.");
//                         }
//                     });
//                 });
//
//                 // 댓글 입력창 비우기
//                 $("textarea[name='commentText']").val("");
//             },
//             error: function (xhr, status, error) {
//                 console.error("댓글 추가 실패: ", error);
//             }
//         });
//     });
// });

// 댓글 작성 기능
$(document).ready(function () {
    $(".comment-submit").click(function (event) {
        event.preventDefault();

        var boardId = this.getAttribute('boardId');
        var memberId = this.getAttribute('memberId');
        var commentText = $("textarea[name='commentText']").val().trim();

        if (commentText === "") {
            alert("댓글을 입력해주세요.");
            return;
        }

        $.ajax({
            url: "/BoardProject/board/comment",
            type: "POST",
            data: {
                boardId: boardId,
                memberId: memberId,
                commentText: commentText
            },
            success: function (response) {
                var commentList = $("#comment-list");

                // 기존 댓글 비우기
                commentList.empty();

                response.comments.forEach(comment => {
                    var formattedDate = new Date(comment.createdAt).toLocaleString();

                    // 댓글 HTML 생성: 공통 클래스를 사용하여 디자인 통일
                    var newCommentHtml = `
                        <div class="comment-container" data-comment-id="${comment.commentId}">
                            <p class="comment-author"><strong>작성자:</strong> ${comment.memberId}</p>
                            <p class="comment-text">${comment.commentText.replace(/\n/g, "<br>")}</p>
                            <p class="comment-info">작성일: ${formattedDate}</p>
                            <button class="delete-comment" data-comment-id="${comment.commentId}">댓글 삭제</button>
                        </div>
                    `;
                    commentList.append(newCommentHtml);
                });

                // 삭제 버튼 클릭 이벤트 핸들러 등록
                $(".delete-comment").click(function () {
                    let commentId = $(this).data("comment-id");
                    let memberId = $("#user-session").data("member-id");
                    if (!confirm("정말 삭제하시겠습니까?")) {
                        return;
                    }

                    $.ajax({
                        url: "board/comment",
                        type: "DELETE",
                        contentType: "application/json",
                        data: JSON.stringify({ commentId: commentId, memberId: memberId }),
                        success: function(response) {
                            if (response.success) {
                                $("div[data-comment-id='" + commentId + "']").fadeOut(300, function() {
                                    $(this).remove();
                                });
                            } else {
                                alert("댓글 삭제 실패!");
                            }
                        },
                        error: function() {
                            alert("서버 오류가 발생했습니다.");
                        }
                    });
                });

                // 댓글 입력창 비우기
                $("textarea[name='commentText']").val("");
            },
            error: function (xhr, status, error) {
                console.error("댓글 추가 실패: ", error);
            }
        });
    });
});