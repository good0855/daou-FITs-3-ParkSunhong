#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <curses.h>
#include <string.h>
#include <math.h>
#include "account.h"
#include "db.h"
#include "user.h"
#include "util.h"
#include "ui.h"
AccountRow account_data; // 계좌 정보 저장
char* date[9];
// 계좌 정보 받아오기 (동적 할당 없이)
AccountRow get_account() {
	FieldMapping mappings[] = {
		{ offsetof(AccountRow, account_id), TYPE_STRING, sizeof(((AccountRow*)0)->account_id) },
		{ offsetof(AccountRow, customer_name), TYPE_STRING, sizeof(((AccountRow*)0)->customer_name) },
		{ offsetof(AccountRow, password), TYPE_STRING, sizeof(((AccountRow*)0)->password) },
		{ offsetof(AccountRow, status), TYPE_INT, sizeof(int) },
		{ offsetof(AccountRow, interest_rate), TYPE_DOUBLE, sizeof(double) },
		{ offsetof(AccountRow, balance), TYPE_DOUBLE, sizeof(double) },
		{ offsetof(AccountRow, total_amount), TYPE_DOUBLE, sizeof(double) }
	};
	int num_fields = sizeof(mappings) / sizeof(FieldMapping);

	char query[1000];
	// SQL 쿼리 작성
	sprintf(query, "SELECT account_id, customer_name, password, status, interest_rate, balance, total_amount "
		"FROM accounts a "
		"JOIN customers c ON a.customer_uuid = c.customer_uuid "
		"WHERE a.customer_uuid = %d", current_user_uuid);

	// AccountRow 구조체로 계좌 정보 조회
	sword ret = executeSelectWithMapping(envhp, svchp, errhp, query, &account_data, mappings, num_fields);

	if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
		return account_data;  // 계좌 정보 반환
	}
	else {
		printf("계좌 정보 조회 실패\n");
		return account_data;  // 실패 시에도 빈 구조체 반환
	}
}

void account_password(void (*page_func)()) {
	clear();
	curs_set(1);
	// 계좌 정보 받아오기
	account_data = get_account();
	// 비밀번호 입력 받기
	char password[20];
	mvprintw(2, 10, "계좌 비밀번호 입력: ");
	move(2, 30);  // 비밀번호 입력 위치로 커서 이동
	echo();
	//getnstr(password, sizeof(password) - 1); // 비밀번호 입력 받기
	// 
	// 마스킹 받기
	get_masked_input(2, 30, password, sizeof(password));
	strncpy(account_data.password, password, sizeof(password) - 1);
	noecho();

	// 비밀번호 검증
	if (strcmp(account_data.password, password) != 0) {
		clear();
		curs_set(0);
		mvprintw(2, 10, "비밀번호가 일치하지 않습니다.");
		mvprintw(4, 10, "아무 키나 눌러 뒤로 가기...");
		refresh();
		getch();
		endwin();
		return;
	}

	// 비밀번호가 일치하면 페이지를 호출
	clear();
	page_func();  // 페이지 함수 호출
}


void account_information() {
	initscr();
	noecho();
	keypad(stdscr, TRUE);
	curs_set(1); // 커서 보이게 설정
	if (account_data.status == 1) {
		clear();
		curs_set(0);
		mvprintw(2, 10, "계좌가 동결되었습니다.");
		mvprintw(4, 10, "관리자에게 문의 바랍니다.");
		mvprintw(6, 10, "아무 키나 눌러 뒤로 가기...");
		refresh();
		getch();
		endwin();
		return;
	}
	// 계좌 정보 출력
	curs_set(0);
	mvprintw(2, 10, "계좌번호: %s", account_data.account_id);
	mvprintw(4, 10, "고객명: %s", account_data.customer_name);
	mvprintw(6, 10, "수익률: %.1lf%%", account_data.interest_rate);
	mvprintw(8, 10, "계좌 잔액: %.0lf", account_data.balance);
	mvprintw(10, 10, "보유 주식 자산: %.0lf", account_data.total_amount);
	mvprintw(14, 10, "아무 키나 눌러 뒤로 가기...");
	refresh();
	getch();
	endwin();
}

MyStockRow* get_stocks(int* fetched_count) {
	FieldMapping fm1 = { offsetof(MyStockRow, account_id), TYPE_STRING, sizeof(((MyStockRow*)0)->account_id) };
	FieldMapping fm2 = { offsetof(MyStockRow, ticker), TYPE_STRING, sizeof(((MyStockRow*)0)->ticker) };
	FieldMapping fm3 = { offsetof(MyStockRow, company_name), TYPE_STRING, sizeof(((MyStockRow*)0)->company_name) };
	FieldMapping fm4 = { offsetof(MyStockRow, quantity), TYPE_INT, sizeof(int) };
	FieldMapping fm5 = { offsetof(MyStockRow, market_cap), TYPE_DOUBLE, sizeof(double) };
	FieldMapping fm6 = { offsetof(MyStockRow, purchase_price), TYPE_DOUBLE, sizeof(double) };
	FieldMapping fm7 = { offsetof(MyStockRow, open_price), TYPE_DOUBLE, sizeof(double) };
	FieldMapping fm8 = { offsetof(MyStockRow, high), TYPE_DOUBLE, sizeof(double) };
	FieldMapping fm9 = { offsetof(MyStockRow, low), TYPE_DOUBLE, sizeof(double) };
	FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5, &fm6, &fm7, &fm8, &fm9 };
	int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

	MyStockRow* rows = NULL;  // 구조체 배열 포인터
	int fetched = 0;          // 가져온 데이터 개수

	char query[1000];
	// 기준 날짜 설정
	getDate(date);
	sprintf(query,
		"SELECT a.account_id, h.ticker, s.company_name, h.quantity, sp.market_cap, h.purchase_price, sp.open_price, sp.high, sp.low "
		"FROM accounts a "
		"INNER JOIN havings h ON a.account_id = h.account_id "
		"INNER JOIN stocks s ON h.ticker = s.ticker "
		"INNER JOIN stocks_price sp ON s.ticker = sp.ticker "
		"WHERE a.customer_uuid = %d AND sp.stock_date = '%s' AND h.purchase_price > 0", current_user_uuid, date);

	// 쿼리 실행하여 데이터 가져오기
	sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query, (void**)&rows, &fetched, mappings, num_fields, sizeof(MyStockRow));

	if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
		if (fetched > 0) {
			*fetched_count = fetched;  // 가져온 데이터 개수 저장
			return rows;  // 구조체 배열 반환 (사용자가 이후 활용 가능)
		}
		else {
			printf("보유 주식 존재하지 않습니다.\n");
			*fetched_count = 0;
			return NULL;
		}
	}
	else {
		printf("쿼리 실행 오류 발생\n");
		*fetched_count = -1;
		return NULL;
	}
}

void format_date(const char* date_str, char* formatted_date) {
	snprintf(formatted_date, 20, "%4.4s년 %2.2s월 %2.2s일", date_str, date_str + 4, date_str + 6);
}


void show_stock_details(MyStockRow* stock) {
	clear();

	// 테두리
	mvprintw(0, 5, "========================================");
	mvprintw(1, 5, "=====  %s 종목 상세 정보  =====", stock->company_name);
	mvprintw(2, 5, "========================================");

	// 날짜 변환
	char formatted_date[20];
	format_date(date, formatted_date);
	mvprintw(4, 5, " 기준 날짜: %s", formatted_date);

	// 주요 정보
	mvprintw(6, 5, " 시가 총액: %.0lf원", stock->market_cap);
	mvprintw(7, 5, " 평균 단가: %.0lf원", stock->purchase_price / stock->quantity);
	mvprintw(8, 5, " 당일 시가: %.0lf원", stock->open_price);
	mvprintw(9, 5, " 최고가: %.0lf원", stock->high);
	mvprintw(10, 5, " 최저가: %.0lf원", stock->low);

	// 수익률 계산 및 표시
	double profit = stock->open_price*stock->quantity - stock->purchase_price;
	double profit_rate = (profit / stock->purchase_price) * 100;

	if (profit >= 0) {
		mvprintw(12, 5, " 손익 금액: ▲ %.0lf원  (%.2f%% 상승)", profit, profit_rate);
	}
	else {
		mvprintw(12, 5, " 손익 금액: ▼ %.0lf원  (%.2f%% 하락)", fabs(profit), fabs(profit_rate));
	}

	// 뒤로 가기 안내
	mvprintw(17, 5, "========================================");
	mvprintw(18, 5, " 뒤로 가기: ESC");

	refresh();

	// 사용자 입력 대기
	int ch = getch();
	if (ch == 27) {  // ESC 키
		account_stock();
	}
}

void account_stock() {
	initscr();
	echo();
	keypad(stdscr, TRUE);
	
	int fetched_count = 0;
	MyStockRow* stock_data = get_stocks(&fetched_count);

	if (stock_data && fetched_count > 0) {
		

		int highlight = 0;  // 현재 선택된 종목
		int choice = -1;    // 선택된 종목 ID (주식 데이터 없음)
		int ch;

		while (1) {
			clear();
			curs_set(0);
			mvprintw(0, 10, "===== 보유 주식 목록 =====");

			// 종목 목록 출력 (선택된 항목 강조)
			for (int i = 0; i < fetched_count; i++) {
				if (i == highlight) {
					attron(A_REVERSE);  // 선택된 항목 강조
				}-
				mvprintw(i + 2, 10, "[%d] %s (%s) - %d주 보유          ", i + 1, stock_data[i].company_name, stock_data[i].ticker, stock_data[i].quantity);
				if (i == highlight) {
					attroff(A_REVERSE);  // 강조 해제
				}
			}
			mvprintw(fetched_count + 2, 10, "뒤로 가기: ESC");
			refresh();

			ch = getch();

			switch (ch) {
			case KEY_UP:
				highlight = (highlight == 0) ? fetched_count - 1 : highlight - 1;  // 위로 이동
				break;
			case KEY_DOWN:
				highlight = (highlight == fetched_count - 1) ? 0 : highlight + 1;  // 아래로 이동
				break;
			case 10:  // Enter 키 눌렀을 때
				choice = highlight;  // 선택한 항목의 인덱스를 저장
				break;
			case 27:  // ESC 키 눌렀을 때
				endwin();
				return;  // 뒤로 가기
			}

			if (choice != -1) {
				show_stock_details(&stock_data[choice]);  // 선택된 종목의 상세 정보 출력
				break;  // 상세 정보를 본 후 종료
			}
		}
		free(stock_data);
	}
	else {
		clear();
		mvprintw(2, 10, "보유 주식이 없습니다.");
		mvprintw(4, 10, "아무 키나 눌러 뒤로 가기...");
		curs_set(0);
		refresh();
		getch();
	}
	endwin();
}

void deposit() {
	char amount_str[20]; // 문자열로 입력받을 버퍼
	int amount = 0;

	initscr();
	keypad(stdscr, TRUE);
	curs_set(1);  // 커서 보이게 설정
	echo();
	// 입력 요청 메시지 출력
	clear();
	mvprintw(2, 10, "입금할 금액을 입력하세요: ");
	move(2, 36); // 입력 위치로 커서 이동
	refresh();
	getnstr(amount_str, sizeof(amount_str)-1);  // 사용자 입력 받기 (문자열)
	curs_set(0);
	noecho();
	amount = atoi(amount_str);  // 문자열 → 정수 변환

	// SQL 쿼리 생성
	char query[1000];
	sprintf(query, "UPDATE accounts SET balance = balance + %d WHERE account_id = '%s'", amount, account_data.account_id);

	// 쿼리 실행
	sword ret1 = executeOCIQuery(envhp, svchp, errhp, query);

	// 결과 처리
	clear();
	curs_set(0);
	if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
		mvprintw(2, 10, "입금이 완료되었습니다.");
	}
	else {
		mvprintw(2, 10, "입금 실패했습니다.");
	}
	mvprintw(4, 10, "아무 키나 누르면 돌아갑니다.");
	refresh();
	getch();  // 사용자 입력 대기
	endwin();  // ncurses 종료
}

int tui_account_page() {
	int highlight = 0;
	int choice = 0;
	const char* menu[] = {
		"계좌 정보 조회           ",
		"보유 주식 조회           ",
		"입금           ",
		"종료           "
	};
	initscr();
	noecho();
	keypad(stdscr, TRUE);
	
	while (1) {
		clear();
		curs_set(0);
		mvprintw(0, 10, "===== [마이페이지] =====");
		for (int i = 0; i < ACCOUNT_MENU_SIZE; i++) {
			if (i == highlight) attron(A_REVERSE);
			mvprintw(i + 2, 10, menu[i]);
			if (i == highlight) attroff(A_REVERSE);
		}
		refresh();
		int key = getch();
		switch (key) {
		case KEY_UP: highlight = (highlight == 0) ? ACCOUNT_MENU_SIZE - 1 : highlight - 1; break;
		case KEY_DOWN: highlight = (highlight == ACCOUNT_MENU_SIZE - 1) ? 0 : highlight + 1; break;
		case 10: choice = highlight; break;
		case KEY_LEFT: endwin(); return 0;
		}
		if (key == 10) {
			endwin();
			if (choice == 0) account_password(&account_information); // 계좌 정보 확인
			else if (choice == 1) account_password(&account_stock);  // 내 보유 주식 확인
			else if (choice == 2) account_password(&deposit);  // 내 보유 주식 확인
			else { return 0; }
		}
	}
}
