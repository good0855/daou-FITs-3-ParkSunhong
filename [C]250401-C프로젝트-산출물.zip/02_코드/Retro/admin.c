#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curses.h>
#include <oci.h>
#include "ui.h"
#include "user.h"
#include "admin.h"
#include "post.h"
#include "db.h"
#include "account.h"
#include "util.h"


//void manage_posts() {
//    printf("게시글 관리 기능을 선택했습니다.\n");
//    // 구현할 기능 추가
//}

//void freeze_account() {
//    printf("계좌 동결 기능을 선택했습니다.\n");
//    // 구현할 기능 추가
//}


void banned_word_page() {
    int cmd;

    while (1) {

        // show all banned words in DB
        select_banned_words();


        printf("\n===== 금지어 관리 =====\n");
        printf("1. 금지어 추가\n");
        printf("2. 나가기\n");
        printf("선택: ");

        scanf_s("%d%*c", &cmd);


        switch (cmd) {
        case 1:
            insert_banned_words(NULL);
            break;
        case 2:
            printf("금지어 추가 기능을 종료합니다.\n");
            return;
        default:
            printf("올바른 번호를 입력하세요.\n");
            break;
        }
    }
}

/*
    Below is the OCI function for connecting with DB
*/

// show banned word in DB
void select_banned_words() {
    const char* query = "SELECT customer_uuid, banned_word FROM banned_words";

    // Set FieldMapping
    FieldMapping fm1 = { offsetof(BannedWordRow, customer_uuid), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(BannedWordRow, banned_word), TYPE_STRING, sizeof(((CustomerRow*)0)->customer_id) };

    FieldMapping* mappings[] = { &fm1, &fm2};
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    BannedWordRow* rows = NULL;
    int fetched = 0;
    int a = sizeof(BannedWordRow);
    
    // result
    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)&rows, &fetched, mappings, num_fields, sizeof(BannedWordRow));

    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        printf("\n금지어 리스트\n", fetched);
        for (int i = 0; i < fetched; i++) {
            printf("Row %d:\n", i + 1);
            printf("  customer_uuid: %d\n", rows[i].customer_uuid);
            printf("  banned_word  : %s\n", rows[i].banned_word);
        }
        free(rows); // free meemory
    }
    else {
        printf("금지어 로딩 실패\n");
    }
}


// show banned word in DB
void tui_select_banned_words(BannedWordListRow** rows, int* num_rows) {
    const char* query =
        "SELECT b.word_id, c.customer_uuid, c.customer_id, c.customer_name, b.banned_word "
        "FROM banned_words b, customers c "
        "WHERE c.customer_uuid = b.customer_uuid "
        "ORDER BY b.word_id DESC";

    FieldMapping fm1 = { offsetof(BannedWordListRow, word_id), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(BannedWordListRow, customer_uuid), TYPE_INT, 0 };
    FieldMapping fm3 = { offsetof(BannedWordListRow, customer_id), TYPE_STRING, sizeof(((BannedWordListRow*)0)->customer_id) };
    FieldMapping fm4 = { offsetof(BannedWordListRow, customer_name), TYPE_STRING, sizeof(((BannedWordListRow*)0)->customer_name) };
    FieldMapping fm5 = { offsetof(BannedWordListRow, banned_word), TYPE_STRING, sizeof(((BannedWordListRow*)0)->banned_word) };

    FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    int fetched = 0;

    // 메모리 할당 (executeSelectAllWithMapping 내부에서 할당하는지 확인 필요)
    *rows = NULL;  // 혹시 모를 기존 포인터 초기화

    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)rows, &fetched, mappings, num_fields, sizeof(BannedWordListRow));

    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        *num_rows = fetched;  // Return the number of rows fetched
        return;
    }
}

// 단어 insert
sword insert_banned_words(char* word) {

    BannedWordInfo bannedWordInfo;
    char input_banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];
    char query_insert[512];

    // set admin uuid and copy string
    bannedWordInfo.admin_uuid = current_user_uuid;
    strcpy_s(bannedWordInfo.banned_word, sizeof(bannedWordInfo.banned_word), word);

    // DB insert logic
    // 3. 계좌 등록
    snprintf(query_insert, sizeof(query_insert),
        "INSERT INTO banned_words (customer_uuid, banned_word) VALUES ('%d', '%s')",
        bannedWordInfo.admin_uuid, bannedWordInfo.banned_word);

    sword ret = executeOCIQuery(envhp, svchp, errhp, query_insert);

    return ret;

}

// 금지어 삭제
sword delete_banned_word(int word_id) {

    BannedWordInfo bannedWordInfo;
    char input_banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];
    char query_delete[512];

    // DB delete
    snprintf(query_delete, sizeof(query_delete),
        "DELETE FROM banned_words WHERE word_id = '%ld'",
        word_id);

    sword ret = executeOCIQuery(envhp, svchp, errhp, query_delete);

    return ret;

}

/*
    Below is TUI Page
*/

// Y or N 선택할 수 있는 이지선다 모달
int tui_show_YN_modal(const char* message) {
    // 모달창 크기 및 위치 설정
    int modal_height = 5;
    int modal_width = 40;
    int modal_y = (LINES - modal_height) / 2;
    int modal_x = (COLS - modal_width) / 2;

    // 모달 윈도우 생성
    WINDOW* modal_win = newwin(modal_height, modal_width, modal_y, modal_x);
    box(modal_win, 0, 0);  // 테두리 추가
    mvwprintw(modal_win, 1, 2, "%s", message);
    mvwprintw(modal_win, 2, 2, "Y: 확인 / N: 취소");

    wrefresh(modal_win);  // 모달창 갱신

    int confirm_key;
    int status = -1;

    while (1) {
        confirm_key = wgetch(modal_win);  // 모달창에서 입력 받기
        if (confirm_key == 'y' || confirm_key == 'Y') {
            status = 1; // 긍정
        }
        else if (confirm_key == 'n' || confirm_key == 'N') {
            status = 0; // 부정
        }
        delwin(modal_win);  // 모달 삭제 후 기존 화면 복구
        clear();
        refresh();

        return status;

    }


}

/*
    [금지어]
*/
// 금지어 메인 페이지
void tui_banned_word_page() {

    int selected = 0; // 현재 선택된 금지어 인덱스

    while (1) {
        initscr();
        keypad(stdscr, TRUE);
        noecho();
        curs_set(0);

        // 금지어 목록을 DB에서 가져와 표시
        int num_rows = 0;
        BannedWordListRow* bannedWordList = NULL;
        tui_select_banned_words(&bannedWordList, &num_rows);

        clear();  // 화면을 지우고 다시 그리기
        mvprintw(0, 10, "===== [금지어 관리] =====");
        mvprintw(1, 10, "[a]: 추가   [d]: 삭제   [q]: 나가기");

        if (num_rows == 0 || bannedWordList == NULL) {
            mvprintw(5, 10, "금지어 목록이 없습니다.");
        }
        else {
            // 금지어 목록의 헤더 출력
            mvprintw(3, 10, "No.    금지어");
            mvprintw(4, 10, "------------------------");

            // 금지어 목록 출력 (선택된 항목 강조)
            for (int i = 0; i < num_rows; i++) {
                if (i == selected) {
                    attron(A_REVERSE); // 선택된 항목 강조
                }

                // 각 금지어 항목 번호와 금지어 표시
                mvprintw(5 + i, 10, "%-4d  %s", i + 1, bannedWordList[i].banned_word);

                if (i == selected) {
                    attroff(A_REVERSE);
                }
            }
        }

        refresh();

        int key = getch();

        switch (key) {
        case 'a':  // 금지어 추가
        case 'A':
            tui_insert_banned_words();
            break;
        case 'd':  // 금지어 삭제
        case 'D':
            if (num_rows > 0) {
                long word_id = bannedWordList[selected].word_id;  // 선택된 항목의 word_id를 가져옴
                int delete_status = tui_delete_banned_words(word_id);  // 삭제 함수 호출
                if (delete_status == 0) {
                    // 삭제 성공 시 선택된 항목을 하나 감소
                    selected = (selected > 0) ? selected - 1 : 0;
                }
            }
            break;
        case KEY_UP:  // 위 방향키
            if (num_rows > 0 && selected > 0) {
                selected--;
            }
            break;
        case KEY_DOWN:  // 아래 방향키
            if (num_rows > 0 && selected < num_rows - 1) {
                selected++;
            }
            break;
        case 'q':  // 나가기
        case 'Q':
            mvprintw(7 + num_rows, 10, "금지어 관리 기능을 종료합니다.\n");
            refresh();
            free(bannedWordList);  // 동적 메모리 해제
            endwin();  // ncurses 종료
            return;  // 종료
        default:
            break;
        }

        free(bannedWordList);  // 동적 메모리 해제
    }

    endwin();
}

// 단순히 금지 단어 보여주는 코드
void tui_show_banned_words(BannedWordListRow* bannedWordList, int num_rows) {
    // 금지어 목록을 화면에 표시
    mvprintw(6, 10, "===== 금지어 목록 =====");

    // 각 금지어 항목 출력
    for (int i = 0; i < num_rows; i++) {
        // 각 항목을 화면에 출력
        mvprintw(7 + i, 10, "ID: %ld, 아이디: %s, 이름: %s, 금지어: %s",
            bannedWordList[i].customer_uuid,
            bannedWordList[i].customer_id,
            bannedWordList[i].customer_name,
            bannedWordList[i].banned_word);
    }
    refresh();  // 화면을 업데이트
}


// 금지 언어 insert
void tui_insert_banned_words() {
    BannedWordInfo bannedWordInfo;
    char input_banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];
    int status;  // 추가 여부 status

    while (1) {
        clear();
        initscr();
        cbreak();  // 입력을 즉시 처리하도록 설정
        keypad(stdscr, TRUE);
        echo();  // 입력한 글자가 화면에 보이도록 설정 (noecho()의 반대)

        curs_set(1);  // 커서 표시
        move(1, 10);  // 커서 위치 (행 1, 열 10)으로 이동
        mvprintw(1, 10, "[금지어를 입력하세요]");
        refresh();

        move(3, 10);  // 금지어 입력을 받을 위치로 커서를 이동
        getstr(input_banned_word);

        // "추가하시겠습니까?" 모달 표시
        curs_set(0);  // 커서 표시 끄기
        status = tui_show_YN_modal("추가하시겠습니까?");

        if (status == 1) {
            // 'Y'를 눌렀을 때 금지어 추가 로직
            sword ret = insert_banned_words(input_banned_word);

            clear();
            curs_set(0);  // 커서 표시 끄기
            if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
                mvprintw(1, 10, "[금지어 등록 성공]");
                return;
            }
            else {
                mvprintw(1, 10, "[금지어 등록 실패]");
                return;
            }
        }
        else {
            // 화면 갱신
            refresh();

            // 이전 페이지로 돌아가기
            clear();
        }
    }
}

// 금지 언어 delete
int tui_delete_banned_words(long word_id) {
    BannedWordInfo bannedWordInfo;
    char input_banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];
    int status;  // 추가 여부 status

    status = tui_show_YN_modal("삭제하시겠습니까?");

    // 삭제 버튼(Y)을 누르면
    if (status == 1) {
        // 'Y'를 눌렀을 때 금지어 추가 로직
        sword ret = delete_banned_word(word_id);

        if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
            mvprintw(1, 10, "[금지어 삭제 성공]");
            return 1;
        }
        else {
            mvprintw(1, 10, "[금지어 삭제 실패]");
            return 0;
        }
    }
    // 삭제하지 않는다면(N)
    else {
        return 0;
    }
}

/*
    [계좌 동결]
*/

// 계좌 동결 메인 페이지
void tui_freeze_account_page() {
    int selected = 0; // 현재 선택된 계좌 인덱스

    while (1) {
        initscr();
        keypad(stdscr, TRUE);
        noecho();
        curs_set(0);

        // 계좌 목록을 DB에서 가져와 표시
        int num_rows = 0;
        AccountListRow* AccountList = NULL;
        tui_select_accounts(&AccountList, &num_rows);

        clear();  // 화면을 지우고 다시 그리기
        mvprintw(0, 10, "===== [계좌 동결] =====");
        mvprintw(1, 10, "[a]: 동결/해제   [q]: 나가기");

        if (num_rows == 0 || AccountList == NULL) {
            mvprintw(5, 10, "계좌 목록이 없습니다.");
        }
        else {
            // 계좌 목록 헤더 출력
            mvprintw(3, 10, "No.   계좌번호            고객UUID   잔액(원)  수익률  상태");
            mvprintw(4, 10, "--------------------------------------------------------");

            // 계좌 목록 출력 (선택된 항목 강조)
            for (int i = 0; i < num_rows; i++) {
                if (i == selected) {
                    attron(A_REVERSE); // 선택된 항목 강조
                }

                mvprintw(5 + i, 10, "%-4d %-20s %-10ld %-10ld %-6.2f %-3s",
                    i + 1, AccountList[i].account_id, AccountList[i].customer_uuid,
                    AccountList[i].total_amount, AccountList[i].interest_rate,
                    AccountList[i].status == 0 ? "정상   " : "동결   ");

                if (i == selected) {
                    attroff(A_REVERSE);
                }
            }
        }

        refresh();

        int key = getch();

        switch (key) {
        case 'a':  // 계좌 동결/해제
        case 'A':
            if (num_rows > 0) {
                clear();
                refresh();
                int current_status = AccountList[selected].status;
                int new_status = (current_status == 0) ? 1 : 0;
                const char* message = (current_status == 0)
                    ? "동결하시겠습니까?"
                    : "해제하시겠습니까?";

                // 모달 창 호출 (사용자가 'Y' 선택 시에만 변경)
                if (tui_show_YN_modal(message) == 1) {
                    update_account_status(AccountList[selected].account_id, new_status);
                }

                // 변경 사항 반영을 위해 목록 다시 불러오기
                free(AccountList);
                AccountList = NULL;
            }
            break;

        case KEY_UP:  // 위 방향키
            if (num_rows > 0 && selected > 0) {
                selected--;
            }
            break;
        case KEY_DOWN:  // 아래 방향키
            if (num_rows > 0 && selected < num_rows - 1) {
                selected++;
            }
            break;
        case 'q':  // 나가기
        case 'Q':
            mvprintw(7 + num_rows, 10, "계좌 관리 기능을 종료합니다.");
            refresh();
            free(AccountList);  // 동적 메모리 해제
            endwin();  // ncurses 종료
            return;  // 종료
        default:
            break;
        }

        free(AccountList);  // 동적 메모리 해제 (반복문 끝에서 한 번만)
    }
}

// 계좌 리스트
void tui_select_accounts(AccountListRow** rows, int* num_rows) {
    const char* query =
        //"select a.account_id, c.customer_uuid, c.customer_id, c.customer_name, a.total_amount, a.interest_rate, a.status "
        "select a.account_id, c.customer_uuid, a.total_amount, a.interest_rate, a.status "
        "from accounts a, customers c "
        "where a.customer_uuid = c.customer_uuid "
        "order by c.customer_uuid desc";

    FieldMapping fm1 = { offsetof(AccountListRow, account_id), TYPE_STRING, sizeof(((AccountListRow*)0)->account_id)+1 };
    FieldMapping fm2 = { offsetof(AccountListRow, customer_uuid), TYPE_INT, 0 };/*
    FieldMapping fm3 = { offsetof(AccountListRow, customer_id), TYPE_STRING, sizeof(((AccountListRow*)0)->customer_id)+1 };
    FieldMapping fm4 = { offsetof(AccountListRow, customer_name), TYPE_STRING, sizeof(((AccountListRow*)0)->customer_name)+1 };*/
    FieldMapping fm5 = { offsetof(AccountListRow, total_amount), TYPE_INT, 0 };
    FieldMapping fm6 = { offsetof(AccountListRow, interest_rate), TYPE_DOUBLE, 0 };
    FieldMapping fm7 = { offsetof(AccountListRow, status), TYPE_INT, 0 };

    //FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5, &fm6, &fm7 };
    FieldMapping* mappings[] = { &fm1, &fm2, &fm5, &fm6, &fm7 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    int fetched = 0;

    // 메모리 할당 (executeSelectAllWithMapping 내부에서 할당하는지 확인 필요)
    *rows = NULL;  // 혹시 모를 기존 포인터 초기화

    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)rows, &fetched, mappings, num_fields, sizeof(AccountListRow));

    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        *num_rows = fetched;  // Return the number of rows fetched
        return;
    }
    else {
        check_error(errhp);
    }
}

// 계좌 상태 업데이트 함수 (DB 반영)
sword update_account_status(const char* account_id, int new_status) {
    char query_update[1024];

    // SQL 쿼리 문자열 구성
    snprintf(query_update, sizeof(query_update),
        "UPDATE accounts SET status = '%d' WHERE account_id = '%s'",
        new_status, account_id);

    // OCI 실행 (query_update로 실행)
    sword ret = executeOCIQuery(envhp, svchp, errhp, query_update);

    return ret; // 실행 결과 반환
}

void save_stocks_to_json() {
    char query[] = "SELECT c.customer_name, s.company_name, h.purchase_price "
        "FROM havings h "
        "JOIN accounts a ON h.account_id = a.account_id "
        "JOIN stocks s ON s.ticker = h.ticker "
        "JOIN customers c ON c.customer_uuid = a.customer_uuid "
        "ORDER BY c.customer_name";

    // SQL 쿼리 실행을 위한 필드 매핑 설정
    FieldMapping fm1 = { offsetof(StockJsonRow, customer_name), TYPE_STRING, sizeof(((StockJsonRow*)0)->customer_name) };
    FieldMapping fm2 = { offsetof(StockJsonRow, company_name), TYPE_STRING, sizeof(((StockJsonRow*)0)->company_name) };
    FieldMapping fm3 = { offsetof(StockJsonRow, purchase_price), TYPE_DOUBLE, sizeof(((StockJsonRow*)0)->purchase_price) };

    FieldMapping* mappings[] = { &fm1, &fm2, &fm3 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    int fetched = 0;
    StockJsonRow* rows = NULL;  // 결과 저장을 위한 배열

    // SQL 쿼리 실행 (Oracle DB API 사용)
    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)&rows, &fetched, mappings, num_fields, sizeof(StockJsonRow));

    if (ret != OCI_SUCCESS && ret != OCI_SUCCESS_WITH_INFO) {
        check_error(errhp);  // 오류 처리
        return;
    }

    // 파일 열기
    FILE* fp = fopen("stocks_data.json", "w");
    if (!fp) {
        printf("파일 열기 실패\n");
        return;
    }

    // JSON 시작
    fprintf(fp, "{\n");

    char current_customer[10] = "";  // 현재 고객 이름을 추적
    int first_customer = 1;  // 첫 번째 고객을 위한 flag

    // SQL 결과를 JSON으로 변환
    for (int i = 0; i < fetched; i++) {
        // 고객이 바뀌면, 새로운 고객 시작
        if (strcmp(current_customer, rows[i].customer_name) != 0) {
            if (!first_customer) {
                fprintf(fp, "    },\n");
            }
            fprintf(fp, "    \"%s\": {\n", rows[i].customer_name);
            strcpy(current_customer, rows[i].customer_name);
            first_customer = 0;
        }

        // 회사 이름과 구매 가격을 출력
        fprintf(fp, "        \"%s\": %.2f", rows[i].company_name, rows[i].purchase_price);

        // 현재 항목이 마지막 항목이 아니고, 다음 항목과 고객 이름이 같으면 쉼표 추가
        if (i < fetched - 1 && strcmp(rows[i].customer_name, rows[i + 1].customer_name) == 0) {
            fprintf(fp, ",\n");
        }
        else {
            fprintf(fp, "\n");
        }
    }

    // 마지막 고객의 닫는 중괄호
    fprintf(fp, "    }\n");

    // JSON 끝
    fprintf(fp, "}\n");

    // 파일 닫기
    fclose(fp);

    clear();
    system("start chrome --incognito http://localhost:8000/piechart_plotly.html");
    mvprintw(2, 10, "json 파일 저장이 완료되었습니다.");
    mvprintw(4, 10, "아무 키나 눌러 뒤로 가기...");
    refresh();
    getch();
    endwin();
    return;

}

void set_next_day() {
    clear();
    dayPass();
    mvprintw(2, 10, "날짜 변경이 완료되었습니다.");
    mvprintw(4, 10, "아무 키나 눌러 뒤로 가기...");
    refresh();
    getch();
    endwin();
    return;
}

// 관리자 게시글 관리

PostRow* post_data;
void tui_admin_post_list() {
    int fetched_count = 0;
    post_data = getPost(&fetched_count);

    if (!post_data || fetched_count == 0) {
        initscr();
        noecho();
        curs_set(0);
        clear();
        mvprintw(2, 10, "게시물이 존재하지 않습니다.");
        mvprintw(4, 10, "아무 키나 누르면 돌아갑니다.");
        refresh();
        getch();
        endwin();
        return;
    }

    int highlight = 0;
    int choice = -1;

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    while (1) {
        clear();
        mvprintw(0, 10, "===== 게시판 =====");

        for (int i = 0; i < fetched_count; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(i + 2, 10, "[%d] %s      ", post_data[i].post_id, post_data[i].title);
            if (i == highlight) attroff(A_REVERSE);
        }

        mvprintw(fetched_count + 3, 10, "뒤로 가기: ESC");
        refresh();

        int key = getch();
        switch (key) {
        case KEY_UP:
            highlight = (highlight == 0) ? fetched_count - 1 : highlight - 1;
            break;
        case KEY_DOWN:
            highlight = (highlight == fetched_count - 1) ? 0 : highlight + 1;
            break;
        case 10:  // Enter 키 입력 시 선택한 게시글 보기
            choice = highlight;
            break;
        case 27:  // ESC 키 입력 시 뒤로 가기
            endwin();
            return;
        }

        if (choice != -1) {
            endwin();
            tui_admin_detail_post(choice);
            return;
        }
    }
}


int tui_admin_detail_post(int index) {
    PostRow selected_post = post_data[index];

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    const char** menu;
    int menu_size;
    int highlight = 0;

    // 현재 사용자가 관리자인지 확인
    if (current_user_type == 1) {
        // 게시글 작성자일 경우: 수정, 삭제, 뒤로 가기 메뉴 제공
        menu_size = 3;
        menu = (const char* []){ "게시글 수정      ", "게시글 삭제      ", "뒤로 가기      " };
    }
    else {
        // 다른 사용자의 게시글이면 "뒤로 가기"만 표시
        menu_size = 1;
        menu = (const char* []){ "뒤로 가기      " };
    }

    while (1) {
        clear();
        mvprintw(0, 10, "===== 게시글 상세 =====");
        mvprintw(2, 10, "제목: %s", selected_post.title);
        mvprintw(3, 10, "작성자: %s", selected_post.customer_name);
        mvprintw(4, 10, "작성 일자: %s", selected_post.created_at);

        // 내용 출력 (줄바꿈 고려)
        int line = 6;
        char* content = strdup(selected_post.content);
        char* token = strtok(content, "\n");
        while (token) {
            mvprintw(line++, 10, "%s", token);
            token = strtok(NULL, "\n");
        }
        free(content);

        // 메뉴 출력
        mvprintw(line + 2, 10, "=====================");
        for (int i = 0; i < menu_size; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(line + 4 + i, 10, "%s", menu[i]);
            if (i == highlight) attroff(A_REVERSE);
        }

        refresh();
        int key = getch();
        switch (key) {
        case KEY_UP:
            highlight = (highlight == 0) ? menu_size - 1 : highlight - 1;
            break;
        case KEY_DOWN:
            highlight = (highlight == menu_size - 1) ? 0 : highlight + 1;
            break;
        case 10:  // Enter 키 입력 시 실행
            endwin();
            if (current_user_type == 1) {
                // 게시글 작성자일 경우
                if (highlight == 0) update_post(selected_post, index);  // 수정
                else if (highlight == 1) admin_delete_post(selected_post.post_id, index);  // 삭제
                else tui_admin_post_list();  // 뒤로 가기
            }
            else {
                // 게시글 작성자가 아닐 경우
                tui_admin_post_list();  // 뒤로 가기
            }
            return 0;
        }
    }
}

void admin_delete_post(int post_id, int index) {
    initscr();
    noecho();
    keypad(stdscr, TRUE);

    // 삭제 확인 모달
    int status = tui_show_YN_modal("삭제 하시겠습니까?");

    if (status == 0) {  // 사용자가 "아니오"를 선택한 경우
        endwin();
        tui_admin_detail_post(index);  // 원래 게시글 상세 화면으로 복귀
        return;
    }

    // 삭제 실행
    char query[1000];
    sprintf(query, "DELETE FROM posts WHERE post_id = '%d'", post_id);
    sword ret1 = executeOCIQuery(envhp, svchp, errhp, query);

    clear();
    curs_set(0);
    if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
        mvprintw(10, 10, "게시글 삭제 완료!");
    }
    else {
        mvprintw(10, 10, "게시글 삭제 실패.");
    }

    mvprintw(12, 10, "아무 키나 눌러 뒤로 가기...");
    refresh();
    getch();  // 사용자 입력 대기

    endwin();
    tui_admin_post_list();  // 삭제 후 게시글 목록으로 이동
}
