﻿#pragma once

#ifndef DB
#define DB
#endif

#define OCI_UTF8ID 871
#include <oci.h>

// 각 필드 타입을 구분하기 위한 열거형
typedef enum {
    TYPE_INT,
    TYPE_DOUBLE,
    TYPE_STRING
} FieldType;

// 구조체의 필드 정보를 담는 메타데이터
typedef struct {
    size_t offset;   // 구조체 내에서 해당 필드의 시작 오프셋 (offsetof() 활용)
    FieldType type;  // 필드의 타입 (예: int, double, string)
    size_t size;     // 문자열인 경우 배열의 크기, int, double은 sizeof() 사용
} FieldMapping;

// 예시로 사용할 구조체 (예: 두 개의 int, 한 개의 double, 한 개의 문자열)
typedef struct {
    int col1;
    char col2[50];
    char col3[50];
    char col4[50];
} MyRow;

typedef struct {
	int customer_uuid;
	char customer_id[50];
	char customer_pw[50];
	char customer_name[50];
	int customer_type;
} CustomerRow;


// DB관련 전역변수 선연
extern OCIEnv* envhp;
extern OCIError* errhp;
extern OCISvcCtx* svchp;
extern OCISession* usrhp;
extern OCIServer* srvhp;

// DB에러 탐지
void check_error(OCIError* errhp);

// DB초기화
void init_db();

// DB연결 해제
void close_db();

// DB select 쿼리 실행
sword executeSelectWithMapping(OCIEnv* envhp, OCISvcCtx* svchp, OCIError* errhp,
    const char* sql, void* row, FieldMapping* mappings, int num_fields);
sword executeSelectAllWithMapping(OCIEnv* envhp, OCISvcCtx* svchp, OCIError* errhp,
    const char* sql, void** rows, int* fetched_rows,
    FieldMapping** mappings, int num_fields, size_t row_size);

// DB쿼리 실행
sword executeOCIQuery(OCIEnv* envhp, OCISvcCtx* svchp, OCIError* errhp, const char* sql);

