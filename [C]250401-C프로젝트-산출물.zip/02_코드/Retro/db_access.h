#pragma once

#ifndef DB_ACCESS_H
#define DB_ACCESS_H

#define DB_USERNAME "C##realkk"
#define DB_PASSWORD "real"
#define DB_DBNAME "192.168.31.235:1521/xe"

#endif