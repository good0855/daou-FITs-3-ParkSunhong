#define _CRT_SECURE_NO_WARNINGS

#include <curses.h>
#include <string.h>
#include <oci.h>
#include "user.h"
#include "db.h"
#include "test.h"
#include "admin.h"
#include "ui.h"
#include "trade.h"
#include "util.h"




int user_test() {
    // const char* query_insert = "INSERT INTO customers (customer_uuid, customer_id, customer_pw, customer_name, customer_type) VALUES (5, 'hong', 'kill', '활빈당', 0)";
    //sword ret1 = executeOCIQuery(envhp, svchp, errhp, query_insert);
    //if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
    //    printf("입력 쿼리 실행 성공\n");
    //}
    //else {
    //    printf("입력 쿼리 실행 실패\n");
    //}

  //  // 실행할 SELECT 쿼리 예시 (쿼리의 컬럼 순서와 아래 mapping 순서가 일치해야 함)
  //  const char* query = "select * from customers where customer_id = 'hong'";

  //  // 결과를 저장할 구조체
  //  CustomerRow row = { 0 };

  //  // FieldMapping 배열 정의
  //  FieldMapping mappings[] = {
  //      { offsetof(CustomerRow, customer_uuid), TYPE_INT, 0 },
  //      { offsetof(CustomerRow, customer_id), TYPE_STRING, sizeof(row.customer_id) },
		//{ offsetof(CustomerRow, customer_pw), TYPE_STRING, sizeof(row.customer_pw) },
		//{ offsetof(CustomerRow, customer_name), TYPE_STRING, sizeof(row.customer_name) },
		//{ offsetof(CustomerRow, customer_type), TYPE_INT, 0 }
  //  };
  //  int num_fields = sizeof(mappings) / sizeof(FieldMapping);

  //  sword ret = executeSelectWithMapping(envhp, svchp, errhp, query, &row, mappings, num_fields);
  //  if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
  //      printf("쿼리 실행 성공\n");
  //      printf("col1: %d\n", row.customer_uuid);
  //      printf("col2: %s\n", row.customer_id);
  //      printf("col3: %s\n", row.customer_pw);
  //      printf("col4: %s\n", row.customer_name);
		//printf("col5: %d\n", row.customer_type);
  //  }
  //  else {
  //      printf("쿼리 실행 실패\n");
  //  }


    const char* query = "SELECT * FROM customers";

    // �� �ʵ忡 ���� FieldMapping ���� ����
    FieldMapping fm1 = { offsetof(CustomerRow, customer_uuid), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(CustomerRow, customer_id), TYPE_STRING, sizeof(((CustomerRow*)0)->customer_id) };
    FieldMapping fm3 = { offsetof(CustomerRow, customer_pw), TYPE_STRING, sizeof(((CustomerRow*)0)->customer_pw) };
    FieldMapping fm4 = { offsetof(CustomerRow, customer_name), TYPE_STRING, sizeof(((CustomerRow*)0)->customer_name) };
    FieldMapping fm5 = { offsetof(CustomerRow, customer_type), TYPE_INT, 0 };

    // FieldMapping ������ �迭 ���� (�÷� ������ ���� SELECT ������ �����ؾ� ��)
    FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    // �������� ����� ������ CustomerRow �迭 (�Լ� ������ �Ҵ��)
    CustomerRow* rows = NULL;
    int fetched = 0;
    int a = sizeof(CustomerRow);
    // ���� �Ҵ��� ���� ���� ���� �����ɴϴ�.
    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)&rows, &fetched, mappings, num_fields, sizeof(CustomerRow));

    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        printf("���� ���� ����: �� %d��\n", fetched);
        for (int i = 0; i < fetched; i++) {
            printf("Row %d:\n", i + 1);
            printf("  customer_uuid: %d\n", rows[i].customer_uuid);
            printf("  customer_id  : %s\n", rows[i].customer_id);
            printf("  customer_pw  : %s\n", rows[i].customer_pw);
            printf("  customer_name: %s\n", rows[i].customer_name);
            printf("  customer_type: %d\n", rows[i].customer_type);
        }
        free(rows);  // ���� �Ҵ�� ��� �迭 ����
    }
    else {
        printf("���� ���� ����\n");
    }

    return 0;
}

// 로그인 테스트
int user_login_test() {
    signin();
}

int trade_test() {
	executeProcessTransactionWithDate();
}

// 메인 UI 페이지 테스트
void tui_main_page_test() {
	tui_main_page();
}

void tui_user_page_test() {
	tui_user_page();
}