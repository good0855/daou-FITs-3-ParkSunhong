#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <oci.h>
#include <curses.h>
#include "trade.h"
#include "util.h"
#include "db.h"
#include "user.h"

#define MAX_STOCK_ROWS 10

extern OCIEnv* envhp;
extern OCISvcCtx* svchp;
extern OCIError* errhp;

int compareBuyOrders(const void* a, const void* b) {
    const OrderRow* orderA = (const OrderRow*)a;
    const OrderRow* orderB = (const OrderRow*)b;

    // 높은 가격 우선
    if (orderA->order_price != orderB->order_price)
        return orderB->order_price - orderA->order_price;

    // 가격이 같으면 수량 높은 순
    return orderB->amount - orderA->amount;
}

char* getQueryWithToday(const char* filePath) {
    // 날짜 초기화 및 문자열 얻기
    //initDate();
    char dateStr[9] = { 0 };
    getDate(dateStr);

    // 날짜 문자열 길이 검증 ("YYYYMMDD" 형식이어야 함)
    if (strlen(dateStr) != 8) {
        printf("invalid date: %s\n", dateStr);
        return NULL;
    }

    // 인자로 받은 파일 경로에서 SQL 스크립트 파일 읽기
    FILE* fp = fopen(filePath, "r");
    if (!fp) {
        printf("FAIL: open SQL file(%s)\n", filePath);
        return NULL;
    }
    fseek(fp, 0, SEEK_END);
    long fileSize = ftell(fp);
    rewind(fp);

    char* fileContent = (char*)malloc(fileSize + 1);
    if (!fileContent) {
        fclose(fp);
        printf("메모리 할당 실패.\n");
        return NULL;
    }
    size_t bytesRead = fread(fileContent, 1, fileSize, fp);
    fileContent[bytesRead] = '\0';
    fclose(fp);

    // BOM(Byte Order Mark) 검사 및 제거 (UTF-8 BOM: 0xEF, 0xBB, 0xBF)
    if (bytesRead >= 3 &&
        (unsigned char)fileContent[0] == 0xEF &&
        (unsigned char)fileContent[1] == 0xBB &&
        (unsigned char)fileContent[2] == 0xBF) {
        memmove(fileContent, fileContent + 3, bytesRead - 3 + 1); // 널 종료 문자 포함
		printf("BOM detected and removed\n");
    }

    // SQL 스크립트 내의 ":today" 문자열 위치 찾기
    char* pos = strstr(fileContent, ":today");
    if (!pos) {
        // 치환 대상이 없으면 원본 쿼리 반환
        return fileContent;
    }

    // 새 문자열 길이 계산: 기존 길이 - ":today"(6글자) + 오늘 날짜 문자열 길이(8글자)
    int oldLen = strlen(fileContent);
    int newLen = oldLen - 6 + strlen(dateStr);
    char* newQuery = (char*)malloc(newLen + 1);
    if (!newQuery) {
        free(fileContent);
        printf("메모리 할당 실패.\n");
        return NULL;
    }

    // :today 치환: 앞부분, 오늘 날짜, 뒷부분 순으로 이어붙이기
    int prefixLen = pos - fileContent;
    strncpy(newQuery, fileContent, prefixLen);
    newQuery[prefixLen] = '\0';
    strcat(newQuery, dateStr);
    strcat(newQuery, pos + 6);  // ":today" 이후 부분

    free(fileContent);
    return newQuery;
}

sword executeProcessTransactionWithDate() {
	char* query = getQueryWithToday("./query/process-transaction.sql");
	if (!query) {
		printf("query is NULL\n");
		return OCI_ERROR;
	}

    sword status = executeOCIQuery(envhp, svchp, errhp, query);
#ifdef DEBUG
    if (status == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        printf("process-transaction.sql executed successfully\n");
    }
    else {
        printf("process-transaction.sql execution failed\n");
    }
#endif
	free(query);
    return status;
}

sword getStockInfo(StockRow** rows) {
    char* query = getQueryWithToday("./query/extract_top10_company.sql");
    if (!query) {
        printf("query is NULL\n");
        return OCI_ERROR;
    }


    FieldMapping fm1 = { offsetof(StockRow, ticker), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(StockRow, company_name), TYPE_STRING, sizeof(((StockRow*)0)->company_name) };
    FieldMapping fm3 = { offsetof(StockRow, open_price), TYPE_INT, 0 };
    FieldMapping fm4 = { offsetof(StockRow, high), TYPE_INT, 0 };
    FieldMapping fm5 = { offsetof(StockRow, low), TYPE_INT, 0 };
    FieldMapping fm6 = { offsetof(StockRow, market_cap), TYPE_DOUBLE, 0 };
    FieldMapping fm7 = { offsetof(StockRow, stock_date), TYPE_STRING, sizeof(((StockRow*)0)->stock_date) };

	FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5, &fm6, &fm7 };
	int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

	int fetched = 0;
	sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
		(void**)rows, &fetched, mappings, num_fields, sizeof(StockRow));

#ifdef DEBUG
	if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
		printf("query success: total %d\n", fetched);
        for (int i = 0; i < fetched; i++) {
            printf("Row %d:\n", i + 1);
            printf("  ticker      : %d\n", (*rows)[i].ticker);
            printf("  company_name: %s\n", (*rows)[i].company_name);
            printf("  open_price  : %d\n", (*rows)[i].open_price);
            printf("  high        : %d\n", (*rows)[i].high);
            printf("  low         : %d\n", (*rows)[i].low);
            printf("  market_cap  : %.0f\n", (*rows)[i].market_cap);
            printf("  stock_date  : %s\n", (*rows)[i].stock_date);
        }
        free(*rows);
	}
    else {
        printf("query failed\n");
    }
#endif
    return ret;
}

sword getRandomStockInfo(StockRow** rows) {
    char* query = getQueryWithToday("./query/extract_random10_company.sql");
    if (!query) {
        printf("query is NULL\n");
        return OCI_ERROR;
    }


    FieldMapping fm1 = { offsetof(StockRow, ticker), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(StockRow, company_name), TYPE_STRING, sizeof(((StockRow*)0)->company_name) };
    FieldMapping fm3 = { offsetof(StockRow, open_price), TYPE_INT, 0 };
    FieldMapping fm4 = { offsetof(StockRow, high), TYPE_INT, 0 };
    FieldMapping fm5 = { offsetof(StockRow, low), TYPE_INT, 0 };
    FieldMapping fm6 = { offsetof(StockRow, market_cap), TYPE_DOUBLE, 0 };
    FieldMapping fm7 = { offsetof(StockRow, stock_date), TYPE_STRING, sizeof(((StockRow*)0)->stock_date) };

    FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5, &fm6, &fm7 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    int fetched = 0;
    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)rows, &fetched, mappings, num_fields, sizeof(StockRow));

#ifdef DEBUG
    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        printf("query success: total %d\n", fetched);
        for (int i = 0; i < fetched; i++) {
            printf("Row %d:\n", i + 1);
            printf("  ticker      : %d\n", (*rows)[i].ticker);
            printf("  company_name: %s\n", (*rows)[i].company_name);
            printf("  open_price  : %d\n", (*rows)[i].open_price);
            printf("  high        : %d\n", (*rows)[i].high);
            printf("  low         : %d\n", (*rows)[i].low);
            printf("  market_cap  : %.0f\n", (*rows)[i].market_cap);
            printf("  stock_date  : %s\n", (*rows)[i].stock_date);
        }
        free(*rows);
    }
    else {
        printf("query failed\n");
    }
#endif
    return ret;
}

sword insertTradeWithDate(int amount, char* ticker, char* account_id, int order_price, int buy_sell) {
    char insert_query[1024];
    char today[9] = { 0 };
	getDate(today);
    snprintf(insert_query, sizeof(insert_query),
        "INSERT INTO Trades(amount, left_amount, ticker, account_id, order_price, trade_success, order_date, buy_sell) "
        "VALUES(%d, %d, '%s', '%s', %d, 0, TO_DATE('%s','YYYYMMDD'), %d)",
        amount, amount, ticker, account_id, order_price, today, buy_sell);
    
    sword status = executeOCIQuery(envhp, svchp, errhp, insert_query);
    if (status == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        printf("insert trade successfully\n");
    }
    else {
        printf("insert trade failed\n");
    }

    //free(insert_query);
    return status;
}

void stock_order() {
    StockRow* stocks = NULL;
    sword ret = getStockInfo(&stocks);
    if (ret != OCI_SUCCESS && ret != OCI_SUCCESS_WITH_INFO) {
        printf("주식 정보를 불러오는 데 실패했습니다.\n");
        return;
    }

    int choice = 0;
    printf("\n===== 상위 10개 주식 목록 =====\n");
    for (int i = 0; i < 10; i++) {
        printf("%d. %s (Ticker: %d, Open Price: %d)\n",
            i + 1, stocks[i].company_name, stocks[i].ticker, stocks[i].open_price);
    }
    printf("종목을 선택하세요 (번호): ");
    scanf_s("%d%*c", &choice);
    if (choice < 1 || choice > 10) {
        printf("잘못된 선택입니다.\n");
        // (getStockInfo에서 메모리를 해제한다면 여기서 추가 해제는 불필요합니다.)
        return;
    }

    // 선택한 종목의 ticker를 문자열로 변환
    char ticker_str[20];
    sprintf(ticker_str, "%d", stocks[choice - 1].ticker);

    int order_type = 0;  // 1: 매수, 2: 매도
    printf("1. 매수\n2. 매도\n선택: ");
    scanf_s("%d%*c", &order_type);
    if (order_type != 1 && order_type != 2) {
        printf("잘못된 선택입니다.\n");
        return;
    }
    int amount = 0, order_price = 0;
    printf("수량을 입력하세요: ");
    scanf_s("%d%*c", &amount);
    printf("주문 가격을 입력하세요: ");
    scanf_s("%d%*c", &order_price);

    // 실제 계좌 id는 로그인 시 저장된 값이나, 여기서는 직접 입력 받음
    char account_id[100];
    printf("계좌 ID를 입력하세요: ");
    scanf_s("%s", account_id, (unsigned)_countof(account_id));

    sword trade_status = insertTradeWithDate(amount, ticker_str, account_id, order_price,
        (order_type == 1) ? 1 : 0);
    if (trade_status == OCI_SUCCESS || trade_status == OCI_SUCCESS_WITH_INFO) {
        printf("주문이 성공적으로 등록되었습니다.\n");
    }
    else {
        printf("주문 등록에 실패하였습니다.\n");
    }
}

void getAccountID(char* account_id) {
    char user_id[100];
    extern long current_user_uuid;
    sprintf(user_id, "%ld", current_user_uuid);

    AccountIDRow account = { 0 };
    char query[200];
    sprintf(query, "SELECT TO_CHAR(account_id) FROM accounts WHERE customer_uuid = %s", user_id);
    FieldMapping mappings[] = { { offsetof(AccountIDRow, account_id), TYPE_STRING, sizeof(((AccountIDRow*)0)->account_id) } };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping);
    sword ret = executeSelectWithMapping(envhp, svchp, errhp, query, &account, mappings, num_fields);

    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        //char account_id[20];
		strcpy(account_id, account.account_id);
	}
    else {
        printf("계좌 정보를 불러오는 데 실패했습니다.\n");
    }

	//return account_id;
}

int tui_stock_order(int is_random) {
    int highlight = 0, choice = 0;
    StockRow* stocks = NULL;
    sword ret;
    if (is_random) {
        ret = getRandomStockInfo(&stocks);
    }
    else {
        ret = getStockInfo(&stocks);
    }

    if (ret != OCI_SUCCESS && ret != OCI_SUCCESS_WITH_INFO) {
        initscr();
        clear();
        mvprintw(0, 10, "주식 정보를 불러오는 데 실패했습니다.");
        refresh();
        getch();
        endwin();
        return 0;
    }

    // curses 초기화 (이미 getStockInfo 호출 후 처리된 데이터 사용)
    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    // [1] 상위 10개 종목 메뉴 선택
    while (1) {
        clear();
        mvprintw(0, 10, "===== 상위 10개 주식 목록 (r: 랜덤 재로딩) =====");
        for (int i = 0; i < MAX_STOCK_ROWS; i++) {
            // 첫 번째 줄: 번호와 회사명 (선택 시 하이라이트)
            if (i == highlight)
                attron(A_REVERSE);
            mvprintw(i * 2 + 2, 10, "%2d. %-20s        ", i + 1, stocks[i].company_name);
            if (i == highlight)
                attroff(A_REVERSE);
            // 두 번째 줄: 시가, 최고가, 최저가 정보
            mvprintw(i * 2 + 3, 10, "시가 : %7d   최고가 : %7d   최저가 : %7d",
                stocks[i].open_price, stocks[i].high, stocks[i].low);
        }
        refresh();
        int key = getch();
        switch (key) {
        case KEY_UP:
            highlight = (highlight == 0) ? MAX_STOCK_ROWS - 1 : highlight - 1;
            break;
        case KEY_DOWN:
            highlight = (highlight == MAX_STOCK_ROWS - 1) ? 0 : highlight + 1;
            break;
        case 10:  // Enter 키
            choice = highlight;
            break;
        case KEY_LEFT:
            endwin();
            return 0;
        case 'r':  // 'r' 또는 'R' 키를 누르면 랜덤 주식 정보 재로딩
        case 'R':
            if (stocks != NULL) {
                free(stocks);
                stocks = NULL;
            }
            ret = getRandomStockInfo(&stocks);
            if (ret != OCI_SUCCESS && ret != OCI_SUCCESS_WITH_INFO) {
                mvprintw(0, 10, "랜덤 주식 정보를 불러오는 데 실패했습니다.");
                refresh();
                getch();
            }
            highlight = 0;
            break;
        }
        if (key == 10)
            break;
    }

    // [2] 매수/매도 선택 메뉴
    int order_highlight = 0, order_choice = 0;
    const char* order_menu[2] = { "매수         ", "매도         " };
    while (1) {
        clear();
        mvprintw(0, 10, "주문 종류를 선택하세요:");
        for (int i = 0; i < 2; i++) {
            if (i == order_highlight)
                attron(A_REVERSE);
            mvprintw(i + 2, 10, order_menu[i]);
            if (i == order_highlight)
                attroff(A_REVERSE);
        }
        refresh();
        int key = getch();
        switch (key) {
        case KEY_UP:
            order_highlight = (order_highlight == 0) ? 1 : order_highlight - 1;
            break;
        case KEY_DOWN:
            order_highlight = (order_highlight == 1) ? 0 : order_highlight + 1;
            break;
        case 10:  // Enter 키
            order_choice = order_highlight;
            break;
        case KEY_LEFT:
            endwin();
            return 0;
        }
        if (key == 10)
            break;
    }
    int order_type = order_choice + 1; // 1: 매수, 2: 매도

    // [3] 수량, 주문 가격, 계좌 ID 입력 (getstr 사용)
    char input_buf[100];
    int amount = 0, order_price = 0;
    echo();  // 입력받은 값을 화면에 표시

    // 수량 입력
    clear();
    mvprintw(0, 10, "수량을 입력하세요:         ");
    refresh();
    getstr(input_buf);
    amount = atoi(input_buf);

    // 주문 가격 입력
    clear();
    mvprintw(0, 10, "주문 가격을 입력하세요:           ");
    refresh();
    getstr(input_buf);
    order_price = atoi(input_buf);

    char account_id[100];
    getAccountID(account_id);

    noecho();

    // 선택한 종목의 ticker를 문자열로 변환
    char ticker_str[20];
    sprintf(ticker_str, "%06d", stocks[choice].ticker);

    // 주문 등록 처리
    sword trade_status = insertTradeWithDate(amount, ticker_str, account_id, order_price, order_type);
    clear();
    if (trade_status == OCI_SUCCESS || trade_status == OCI_SUCCESS_WITH_INFO) {
        mvprintw(0, 10, "주문이 성공적으로 등록되었습니다.");
    }
    else {
        mvprintw(0, 10, "주문 등록에 실패하였습니다.");
    }
    refresh();
    getch();
    endwin();

    return 1;
}
