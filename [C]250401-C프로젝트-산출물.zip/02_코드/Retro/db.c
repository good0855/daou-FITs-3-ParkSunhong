﻿// db.c (source file)
#include <oci.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db.h"
#include "db_access.h"


// DB관련 전역변수 선연

OCIEnv* envhp = NULL;
OCIError* errhp = NULL;
OCISvcCtx* svchp = NULL;
OCISession* usrhp = NULL;
OCIServer* srvhp = NULL;
OCIStmt* stmthp;
OCIDefine* def1 = NULL;
sword status;

// 에러 체크
void check_error(OCIError* errhp) {
    text errbuf[512];
    sb4 errcode = 0;
    OCIErrorGet(errhp, 1, NULL, &errcode, errbuf, sizeof(errbuf), OCI_HTYPE_ERROR);
    printf("Oracle Error: %s\n", errbuf);
}

// DB 초기화

//int init_db() {
//
//    // (TODO) 나중에 키 따로 저장하기
//    char* username = "C##realkk";
//    char* password = "real";
//    char* dbname = "192.168.31.235:1521/xe";
//    /*char* dbname = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.31.235)(PORT=1521))"
//        "(CONNECT_DATA=(SERVICE_NAME=xe)))";*/
//        
//
//
//    // OCI 환경 초기화
//    OCIEnvCreate(&envhp, OCI_DEFAULT, NULL, NULL, NULL, NULL, 0, NULL);
//    OCIHandleAlloc(envhp, (void**)&errhp, OCI_HTYPE_ERROR, 0, NULL);
//    OCIHandleAlloc(envhp, (void**)&svchp, OCI_HTYPE_SVCCTX, 0, NULL);
//    OCIHandleAlloc(envhp, (void**)&usrhp, OCI_HTYPE_SESSION, 0, NULL);
//    OCIHandleAlloc(envhp, (void**)&srvhp, OCI_HTYPE_SERVER, 0, NULL);
//
//    // 서버 연결
//    OCIServerAttach(srvhp, errhp, (OraText*)dbname, strlen(dbname), OCI_DEFAULT);
//
//    // 서비스 컨텍스트에 서버 설정
//    OCIAttrSet(svchp, OCI_HTYPE_SVCCTX, srvhp, 0, OCI_ATTR_SERVER, errhp);
//
//    // 사용자 세션 설정
//    OCIAttrSet(usrhp, OCI_HTYPE_SESSION, username, strlen(username), OCI_ATTR_USERNAME, errhp);
//    OCIAttrSet(usrhp, OCI_HTYPE_SESSION, password, strlen(password), OCI_ATTR_PASSWORD, errhp);
//
//    // 세션 시작
//    OCISessionBegin(svchp, errhp, usrhp, OCI_CRED_RDBMS, OCI_DEFAULT);
//    OCIAttrSet(svchp, OCI_HTYPE_SVCCTX, usrhp, 0, OCI_ATTR_SESSION, errhp);
//    printf("DB 연결 성공\n");
//
//    return OCI_SUCCESS;
//}

void init_db() {
    // DB 로그인 정보
    char* username = DB_USERNAME;
    char* password = DB_PASSWORD;
    char* dbname = DB_DBNAME;

    // 환경 핸들 초기화
    if (OCIEnvNlsCreate(&envhp, OCI_DEFAULT, NULL, NULL, NULL, NULL, 0, NULL, OCI_UTF8ID, OCI_UTF8ID) != OCI_SUCCESS) {
        printf("OCIEnvNlsCreate failed\n");
        return -1;
    }
    OCIHandleAlloc(envhp, (void**)&errhp, OCI_HTYPE_ERROR, 0, NULL);
    OCIHandleAlloc(envhp, (void**)&srvhp, OCI_HTYPE_SERVER, 0, NULL);
    OCIServerAttach(srvhp, errhp, (OraText*)dbname, strlen(dbname), OCI_DEFAULT);
    OCIHandleAlloc(envhp, (void**)&svchp, OCI_HTYPE_SVCCTX, 0, NULL);
    OCIAttrSet(svchp, OCI_HTYPE_SVCCTX, srvhp, 0, OCI_ATTR_SERVER, errhp);
    OCIHandleAlloc(envhp, (void**)&usrhp, OCI_HTYPE_SESSION, 0, NULL);
    OCIAttrSet(usrhp, OCI_HTYPE_SESSION, username, strlen(username),
        OCI_ATTR_USERNAME, errhp);
    OCIAttrSet(usrhp, OCI_HTYPE_SESSION, password, strlen(password),
        OCI_ATTR_PASSWORD, errhp);
    OCISessionBegin(svchp, errhp, usrhp, OCI_CRED_RDBMS, OCI_DEFAULT);
    OCIAttrSet(svchp, OCI_HTYPE_SVCCTX, usrhp, 0, OCI_ATTR_SESSION, errhp);
}


// 연결 종료 및 리소스 해제 함수
void close_db() {
    // 자원 해제
    if (usrhp != NULL) {
        OCISessionEnd(svchp, errhp, usrhp, OCI_DEFAULT);
        OCIHandleFree(usrhp, OCI_HTYPE_SESSION);
    }

    if (srvhp != NULL) {
        OCIHandleFree(srvhp, OCI_HTYPE_SERVER);
    }

    if (svchp != NULL) {
        OCIHandleFree(svchp, OCI_HTYPE_SVCCTX);
    }

    if (errhp != NULL) {
        OCIHandleFree(errhp, OCI_HTYPE_ERROR);
    }

    if (envhp != NULL) {
        OCIHandleFree(envhp, OCI_HTYPE_ENV);
    }

    printf("DB 연결 종료\n");
}

/*
 * executeSelectWithMapping
 *   envhp, svchp, errhp : OCI 환경 핸들들 (이미 초기화된 상태)
 *   sql               : 실행할 SELECT 쿼리 (반드시 SELECT 문의 컬럼 순서와 mapping 순서가 동일해야 함)
 *   row               : 쿼리 결과를 저장할 구조체의 포인터 (단일 행만 처리)
 *   mappings          : 각 컬럼에 대한 FieldMapping 배열
 *   num_fields        : mapping 배열의 필드 개수
 *
 * 반환값: OCI_SUCCESS 등 OCI 실행 결과 (성공 시 OCI_SUCCESS)
 */
sword executeSelectWithMapping(OCIEnv* envhp, OCISvcCtx* svchp, OCIError* errhp,
    const char* sql, void* row, FieldMapping* mappings, int num_fields) {

    // Statement 핸들 할당
    status = OCIHandleAlloc(envhp, (dvoid**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    if (status != OCI_SUCCESS) {
        return status;
    }

    // SQL 쿼리 준비
    status = OCIStmtPrepare(stmthp, errhp, (text*)sql, (ub4)strlen(sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (status != OCI_SUCCESS) {
        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        return status;
    }

    // 각 컬럼을 구조체의 해당 멤버와 바인딩
    for (int i = 0; i < num_fields; i++) {
        void* fieldAddr = (char*)row + mappings[i].offset;
        sb4 dty;
        int colSize = 0;

        switch (mappings[i].type) {
        case TYPE_INT:
            dty = SQLT_INT;
            colSize = sizeof(int);
            break;
        case TYPE_DOUBLE:
            dty = SQLT_FLT;  // 또는 SQLT_BDOUBLE (사용하는 Oracle 버전에 따라 다름)
            colSize = sizeof(double);
            break;
        case TYPE_STRING:
            dty = SQLT_STR;
            colSize = mappings[i].size;  // 문자열 버퍼의 크기
            break;
        default:
            // 알 수 없는 타입인 경우 에러 처리
            OCIHandleFree(stmthp, OCI_HTYPE_STMT);
            return OCI_ERROR;
        }

        status = OCIDefineByPos(stmthp, &def1, errhp, i + 1, fieldAddr, colSize, dty,
            NULL, NULL, NULL, OCI_DEFAULT);
        if (status != OCI_SUCCESS) {
            OCIHandleFree(stmthp, OCI_HTYPE_STMT);
            return status;
        }
    }

    // 쿼리 실행 (행 개수 1, 단일 행만 가져오는 예제)
    status = OCIStmtExecute(svchp, stmthp, errhp, 1, 0, NULL, NULL, OCI_DEFAULT);
    if (status != OCI_SUCCESS && status != OCI_SUCCESS_WITH_INFO) {
        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        return status;
    }

    // 결과 fetch (단일 행만 처리)
    status = OCIStmtFetch2(stmthp, errhp, 1, OCI_FETCH_NEXT, 0, OCI_DEFAULT);
    if (status != OCI_SUCCESS && status != OCI_NO_DATA) {
        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        return status;
    }

    // Statement 핸들 해제
    OCIHandleFree(stmthp, OCI_HTYPE_STMT);
    return OCI_SUCCESS;
}

sword executeSelectAllWithMapping(OCIEnv* envhp, OCISvcCtx* svchp, OCIError* errhp,
    const char* sql, void** rows, int* fetched_rows,
    FieldMapping** mappings, int num_fields, size_t row_size)
{
    OCIStmt* stmthp = NULL;
    sword status;
    OCIDefine* defnp = NULL;

    // 초기 결과 저장 버퍼 용량(행 개수)를 10으로 설정하고, 결과 행 수를 0으로 초기화
    int capacity = 10;
    int rowCount = 0;
    void* resultRows = malloc(capacity * row_size);
    if (resultRows == NULL) {
        fprintf(stderr, "메모리 할당 실패\n");
        return OCI_ERROR;
    }

    // 임시 버퍼: fetch한 한 행의 데이터를 저장할 메모리(매번 재사용)
    // calloc을 사용할 수도 있으나, 여기서는 malloc 후 초기화를 수행
    void* tempRow = malloc(row_size);
    if (tempRow == NULL) {
        fprintf(stderr, "tempRow 메모리 할당 실패\n");
        free(resultRows);
        return OCI_ERROR;
    }
    memset(tempRow, 0, row_size);

    // OCI Statement 핸들을 할당
    status = OCIHandleAlloc(envhp, (dvoid**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    if (status != OCI_SUCCESS) {
        free(tempRow);
        free(resultRows);
        return status;
    }

    // SQL 쿼리를 준비 (문자열 sql을 Statement 핸들에 로드)
    status = OCIStmtPrepare(stmthp, errhp, (text*)sql, (ub4)strlen(sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (status != OCI_SUCCESS) {
        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        free(tempRow);
        free(resultRows);
        return status;
    }

    // 각 컬럼에 대해 임시 버퍼 내 해당 필드와 바인딩 (mappings는 FieldMapping* 배열)
    for (int i = 0; i < num_fields; i++) {
        FieldMapping* fm = mappings[i];
        // tempRow에서 해당 필드의 주소를 계산
        void* fieldAddr = (char*)tempRow + fm->offset;
        sb4 dty;
        int colSize = 0;

        // 필드 타입에 따라 Oracle 데이터 타입과 컬럼 크기를 설정
        switch (fm->type) {
        case TYPE_INT:
            dty = SQLT_INT;
            colSize = sizeof(int);
            break;
        case TYPE_DOUBLE:
            dty = SQLT_FLT;  // 필요에 따라 SQLT_BDOUBLE 사용 가능
            colSize = sizeof(double);
            break;
        case TYPE_STRING:
            dty = SQLT_STR;
            colSize = fm->size;  // 문자열 버퍼의 크기
            break;
        default:
            OCIHandleFree(stmthp, OCI_HTYPE_STMT);
            free(tempRow);
            free(resultRows);
            return OCI_ERROR;
        }

        // 각 컬럼을 해당 위치에 바인딩
        status = OCIDefineByPos(stmthp, &defnp, errhp, i + 1, fieldAddr, colSize, dty,
            NULL, NULL, NULL, OCI_DEFAULT);
        if (status != OCI_SUCCESS) {
            OCIHandleFree(stmthp, OCI_HTYPE_STMT);
            free(tempRow);
            free(resultRows);
            return status;
        }
    }

    // SQL 쿼리 실행: 행 개수를 0으로 지정하면 모든 행을 fetch함
    status = OCIStmtExecute(svchp, stmthp, errhp, 0, 0, NULL, NULL, OCI_DEFAULT);
    if (status != OCI_SUCCESS && status != OCI_SUCCESS_WITH_INFO) {
        // 구체적인 에러 메시지를 OCIErrorGet()으로 가져오기
        text errbuf[512];
        sb4 errcode = 0;
        OCIErrorGet(errhp, 1, NULL, &errcode, errbuf, sizeof(errbuf), OCI_HTYPE_ERROR);
        fprintf(stderr, "OCIStmtExecute failed: %s\n", errbuf);

        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        free(tempRow);
        free(resultRows);
        return status;
    }

    // fetch된 각 행을 임시 버퍼에서 resultRows 배열로 복사
    while ((status = OCIStmtFetch2(stmthp, errhp, 1, OCI_FETCH_NEXT, 0, OCI_DEFAULT)) == OCI_SUCCESS) {
        // resultRows 배열의 capacity가 부족하면 realloc으로 버퍼 확장
        if (rowCount >= capacity) {
            capacity *= 2;
            void* temp = realloc(resultRows, capacity * row_size);
            if (temp == NULL) {
                fprintf(stderr, "realloc 실패\n");
                OCIHandleFree(stmthp, OCI_HTYPE_STMT);
                free(tempRow);
                free(resultRows);
                return OCI_ERROR;
            }
            resultRows = temp;
        }
        // 임시 버퍼의 한 행 데이터를 결과 배열의 해당 위치에 복사
        memcpy((char*)resultRows + rowCount * row_size, tempRow, row_size);
        rowCount++;
    }

    // OCIStmtFetch2의 종료 상태가 OCI_NO_DATA 또는 OCI_SUCCESS여야 함
    if (status != OCI_NO_DATA && status != OCI_SUCCESS) {
        // 구체적인 에러 메시지를 OCIErrorGet()으로 가져오기
        text errbuf[512];
        sb4 errcode = 0;
        OCIErrorGet(errhp, 1, NULL, &errcode, errbuf, sizeof(errbuf), OCI_HTYPE_ERROR);
        fprintf(stderr, "OCIStmtExecute failed: %s\n", errbuf);

        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        free(tempRow);
        free(resultRows);
        return status;
    }

    // 결과 배열과 fetch된 행 수를 호출자에게 반환
    *rows = resultRows;
    *fetched_rows = rowCount;

    OCIHandleFree(stmthp, OCI_HTYPE_STMT);
    free(tempRow);
    return OCI_SUCCESS;
}


sword executeOCIQuery(OCIEnv* envhp, OCISvcCtx* svchp, OCIError* errhp, const char* sql) {

    // Statement 핸들 할당
    status = OCIHandleAlloc(envhp, (dvoid**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    if (status != OCI_SUCCESS) {
        check_error(errhp);
        return status;
    }

    // SQL 쿼리 준비 (SQL문을 Statement 핸들에 로드)
    status = OCIStmtPrepare(stmthp, errhp, (text*)sql, (ub4)strlen(sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    if (status != OCI_SUCCESS) {
        check_error(errhp);
        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        return status;
    }

    // SQL 실행 (결과셋이 없는 경우나 단일 행 실행)
    status = OCIStmtExecute(svchp, stmthp, errhp, 1, 0, NULL, NULL, OCI_DEFAULT);
    if (status != OCI_SUCCESS && status != OCI_SUCCESS_WITH_INFO) {
        check_error(errhp);
        return status;
    }

    // 수동 커밋 실행
    status = OCITransCommit(svchp, errhp, OCI_DEFAULT);
    if (status != OCI_SUCCESS) {
        check_error(errhp);
        OCIHandleFree(stmthp, OCI_HTYPE_STMT);
        return status;
    }

    // Statement 핸들 해제
    OCIHandleFree(stmthp, OCI_HTYPE_STMT);

    return status;
}


