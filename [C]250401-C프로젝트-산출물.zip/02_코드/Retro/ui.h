#pragma once

#ifndef UI
#define UI
#endif

#include "admin.h"
#define ADMIN_MENU_SIZE 6
#define USER_MENU_SIZE 4
#define ADMIN_BANNED_NUMS_PAGE 50



/*
	Below is TUI page
*/
void tui_main_page();

int tui_user_page();

int tui_admin_page();

void tui_login();

void tui_signin();


void draw_ascii_art(WINDOW* win);

void loading();