﻿#pragma once

#ifndef USER
#define USER
#endif

#define CUSTOMER_MAX_ID_LENGTH 10
#define CUSTOMER_MAX_PW_LENGTH 20
#define CUSTOMER_MAX_NAME_LENGTH 10
#define ACCOUNT_NUMBER_LENGTH 20 // 계좌번호 자리수

extern long current_user_uuid;
extern int current_user_type;

// 사용자 정보 구조체
typedef struct {
    char customer_id[CUSTOMER_MAX_ID_LENGTH]; // 아이디
    char customer_pw[CUSTOMER_MAX_PW_LENGTH]; // 패스워드
    char customer_name[CUSTOMER_MAX_NAME_LENGTH]; // 고객 이름
    int account_password; // 계좌 비밀번호
} SignInfo;

// 로그인 정보 구조체
typedef struct {
    char customer_id[CUSTOMER_MAX_ID_LENGTH]; // 아이디
    char customer_pw[CUSTOMER_MAX_PW_LENGTH]; // 패스워드
} LoginInfo;

// 회원가입 함수
void signin();

// 계좌개설 함수
void open_account(SignInfo* new_user);

// 로그인
void login();

// 로그아웃
void logout();