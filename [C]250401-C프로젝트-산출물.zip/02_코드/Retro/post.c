#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <curses.h>
#include "post.h"
#include "db.h"
#include "admin.h"
#include "user.h"
#define MAX_BANNED_WORDS 100
#define MAX_WORD_LENGTH 50

char banned_words[MAX_BANNED_WORDS][MAX_WORD_LENGTH]; // 금지어를 저장할 배열
int banned_word_count = 0; // 현재 저장된 금지어 개수
PostRow* post_data;
void get_banned_words() {
    char* query = "SELECT customer_uuid, banned_word FROM banned_words";
    // Set FieldMapping
    FieldMapping fm1 = { offsetof(BannedWordRow, customer_uuid), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(BannedWordRow, banned_word), TYPE_STRING, sizeof(((CustomerRow*)0)->customer_id) };

    FieldMapping* mappings[] = { &fm1, &fm2 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);

    BannedWordRow* rows = NULL;
    int fetched = 0;
    int a = sizeof(BannedWordRow);

    // result
    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query,
        (void**)&rows, &fetched, mappings, num_fields, sizeof(BannedWordRow));

    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        banned_word_count = (fetched < MAX_BANNED_WORDS) ? fetched : MAX_BANNED_WORDS; // 배열 크기 초과 방지
        for (int i = 0; i < fetched; i++) {
            strncpy(banned_words[i], rows[i].banned_word, MAX_WORD_LENGTH - 1);
            banned_words[i][MAX_WORD_LENGTH - 1] = '\0'; // 안전한 문자열 처리
        }
    }
}

// 금지어 포함 여부 검사
int contains_banned_word(const char* text) {
    get_banned_words();
    for (int i = 0; i < banned_word_count; i++) {
        if (strstr(text, banned_words[i]) != NULL) {
            return 1; // 금지어 포함
        }
    }
    return 0;
}



void register_post(int customer_uuid) {
    char title[100];
    char content[500];

    initscr();              // ncurses 초기화
    echo();               // 입력 시 문자를 화면에 출력하지 않음
    curs_set(1);            // 커서 표시
    keypad(stdscr, TRUE);   // 키보드 입력 처리

    // 제목 입력 받기
    clear();
    mvprintw(2, 10, "===== 게시글 등록 =====");
    mvprintw(4, 10, "제목을 입력하세요: ");
    move(4, 30);           // 제목 입력 위치로 커서 이동
    refresh();
    getstr(title);  // 사용자로부터 제목 입력 받기

    // 내용 입력 받기
    mvprintw(6, 10, "내용을 입력하세요: ");
    move(6, 30);           // 내용 입력 위치로 커서 이동
    refresh();
    getstr(content);  // 사용자로부터 내용 입력 받기

    // 금지어 필터링



    if (contains_banned_word(content)) {
        clear();
        curs_set(0);
        mvprintw(2, 10, "금지어가 포함된 게시글은 등록할 수 없습니다.");
        mvprintw(4, 10, "아무 키나 누르면 돌아갑니다.");
        refresh();
        getch();  // 사용자로부터 아무 키 입력 받기
        endwin();  // ncurses 종료
        return;
    }

    // SQL 쿼리 생성
    char query[1000];
    sprintf(query, "INSERT INTO posts (customer_uuid, title, content) VALUES ('%d', '%s', '%s')", customer_uuid, title, content);

    // 쿼리 실행
    sword ret1 = executeOCIQuery(envhp, svchp, errhp, query);

    // 쿼리 실행 결과 처리
    clear();
    curs_set(0);
    if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
        mvprintw(2, 10, "게시글 등록이 성공적으로 완료되었습니다.");
    }
    else {
        mvprintw(2, 10, "게시글 등록에 실패했습니다.");
    }
    mvprintw(4, 10, "아무 키나 누르면 돌아갑니다. ");
    refresh();
    getch();  // 사용자로부터 아무 키 입력 받기
    endwin();  // ncurses 종료
}


PostRow* getPost(int* fetched_count) {
    char* query = "SELECT p.post_id, c.customer_uuid, c.customer_name, p.title, p.content, p.created_at " 
                   "FROM posts p LEFT JOIN customers c ON p.customer_uuid = c.customer_uuid "
                   "ORDER BY p.post_id";
    FieldMapping fm1 = { offsetof(PostRow, post_id), TYPE_INT, 0 };
    FieldMapping fm2 = { offsetof(PostRow, customer_uuid), TYPE_INT, 0 };
    FieldMapping fm3 = { offsetof(PostRow, customer_name), TYPE_STRING, sizeof(((PostRow*)0)->customer_name) };
    FieldMapping fm4 = { offsetof(PostRow, title), TYPE_STRING, sizeof(((PostRow*)0)->title) };
    FieldMapping fm5 = { offsetof(PostRow, content), TYPE_STRING, sizeof(((PostRow*)0)->content) };
    FieldMapping fm6 = { offsetof(PostRow, created_at), TYPE_STRING, sizeof(((PostRow*)0)->created_at) };
    FieldMapping* mappings[] = { &fm1, &fm2, &fm3, &fm4, &fm5, &fm6 };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping*);
    PostRow* rows = NULL;
    int fetched = 0;
    sword ret = executeSelectAllWithMapping(envhp, svchp, errhp, query, (void**)&rows, &fetched, mappings, num_fields, sizeof(PostRow));
    if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        if (fetched > 0) {
            *fetched_count = fetched;  // 가져온 데이터 개수 저장
            return rows;  // 구조체 배열 반환 (사용자가 이후 활용 가능)
        }
        else {
            printf("게시판 글이 존재 않습니다.\n");
            *fetched_count = 0;
            return NULL;
        }
    }
    else {
        printf("쿼리 실행 오류 발생\n");
        *fetched_count = -1;
        return NULL;
    }
}

void tui_post_list() {
    int fetched_count = 0;
     post_data = getPost(&fetched_count);

    if (!post_data || fetched_count == 0) {
        initscr();
        noecho();
        curs_set(0);
        clear();
        mvprintw(2, 10, "게시물이 존재하지 않습니다.");
        mvprintw(4, 10, "아무 키나 누르면 돌아갑니다.");
        refresh();
        getch();
        endwin();
        return;
    }

    int highlight = 0;
    int choice = -1;

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    while (1) {
        clear();
        mvprintw(0, 10, "===== 게시판 =====");

        for (int i = 0; i < fetched_count; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(i + 2, 10, "[%d] %s      ", post_data[i].post_id, post_data[i].title);
            if (i == highlight) attroff(A_REVERSE);
        }

        mvprintw(fetched_count + 3, 10, "뒤로 가기: ESC");
        refresh();

        int key = getch();
        switch (key) {
        case KEY_UP:
            highlight = (highlight == 0) ? fetched_count - 1 : highlight - 1;
            break;
        case KEY_DOWN:
            highlight = (highlight == fetched_count - 1) ? 0 : highlight + 1;
            break;
        case 10:  // Enter 키 입력 시 선택한 게시글 보기
            choice = highlight;
            break;
        case 27:  // ESC 키 입력 시 뒤로 가기
            endwin();
            return;
        }

        if (choice != -1) {
            endwin();
            tui_detail_post(choice);
            return;
        }
    }
}


int tui_detail_post(int index) {
    PostRow selected_post = post_data[index];

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    const char** menu;
    int menu_size;
    int highlight = 0;

    // 현재 사용자가 게시글 작성자인지 확인
    if (current_user_uuid == selected_post.customer_uuid || current_user_uuid == 30) {
        // 게시글 작성자일 경우: 수정, 삭제, 뒤로 가기 메뉴 제공
        menu_size = 3;
        menu = (const char* []){ "게시글 수정      ", "게시글 삭제      ", "뒤로 가기      " };
    }
    else {
        // 다른 사용자의 게시글이면 "뒤로 가기"만 표시
        menu_size = 1;
        menu = (const char* []){ "뒤로 가기      " };
    }

    while (1) {
        clear();
        mvprintw(0, 10, "===== 게시글 상세 =====");
        mvprintw(2, 10, "제목: %s", selected_post.title);
        mvprintw(3, 10, "작성자: %s", selected_post.customer_name);
        mvprintw(4, 10, "작성 일자: %s", selected_post.created_at);
        
        // 내용 출력 (줄바꿈 고려)
        int line = 6;
        char* content = strdup(selected_post.content);
        char* token = strtok(content, "\n");
        while (token) {
            mvprintw(line++, 10, "%s", token);
            token = strtok(NULL, "\n");
        }
        free(content);

        // 메뉴 출력
        mvprintw(line + 2, 10, "=====================");
        for (int i = 0; i < menu_size; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(line + 4 + i, 10, "%s", menu[i]);
            if (i == highlight) attroff(A_REVERSE);
        }

        refresh();
        int key = getch();
        switch (key) {
        case KEY_UP:
            highlight = (highlight == 0) ? menu_size - 1 : highlight - 1;
            break;
        case KEY_DOWN:
            highlight = (highlight == menu_size - 1) ? 0 : highlight + 1;
            break;
        case 10:  // Enter 키 입력 시 실행
            endwin();
            if (current_user_uuid == selected_post.customer_uuid || current_user_uuid == 30) {
                // 게시글 작성자일 경우
                if (highlight == 0) update_post(selected_post, index);  // 수정
                else if (highlight == 1) delete_post(selected_post.post_id, index);  // 삭제
                else tui_post_list();  // 뒤로 가기
            }
            else {
                // 게시글 작성자가 아닐 경우
                tui_post_list();  // 뒤로 가기
            }
            return 0;
        }
    }
}

void update_post(PostRow selected_post, int index) {
    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(1);  // 커서 보이게 설정

    char content[500] = ""; // 새 텍스트 입력을 위한 버퍼
    int max_length = sizeof(content) - 1;
    int idx = 0; // 현재 입력 위치
    int ch;

    while (1) {
        clear();
        mvprintw(0, 10, "===== 게시글 수정 =====");
        mvprintw(2, 10, "제목: %s", selected_post.title);
        mvprintw(4, 10, "내용: %s", content);
        mvprintw(8, 10, "ESC: 취소, Enter: 완료");
        move(4, 16 + idx);  // 커서를 현재 입력 위치로 이동
        refresh();

        ch = getch();

        if (ch == 27) {  // ESC 키 입력 시 취소
            endwin();
            tui_detail_post(index);
            return;
        }
        else if (ch == 10) {  // Enter 입력 시 완료
            break;
        }
        else if (ch == KEY_BACKSPACE || ch == 127) {  // 백스페이스 입력
            if (idx > 0) {
                idx--;
                content[idx] = '\0';
            }
        }
        else if (idx < max_length && isprint(ch)) {  // 일반 문자 입력
            content[idx++] = ch;
            content[idx] = '\0';
        }
    }

    // 수정된 내용 업데이트
    char query[1000];
    sprintf(query, "UPDATE posts SET content = '%s' WHERE post_id = '%d'", content, selected_post.post_id);
    sword ret1 = executeOCIQuery(envhp, svchp, errhp, query);

    clear();
    curs_set(0);
    if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
        int fetched_count = 0;
        post_data = getPost(&fetched_count);
        mvprintw(10, 10, "게시글 수정 완료!");
    }
    else {
        mvprintw(10, 10, "수정 실패.");
    }

    mvprintw(12, 10, "아무 키나 눌러 뒤로 가기...");
    refresh();
    getch();

    endwin();
    tui_detail_post(index);
}

void delete_post(int post_id, int index) {
    initscr();
    noecho();
    keypad(stdscr, TRUE);

    // 삭제 확인 모달
    int status = tui_show_YN_modal("삭제 하시겠습니까?");

    if (status == 0) {  // 사용자가 "아니오"를 선택한 경우
        endwin();
        tui_detail_post(index);  // 원래 게시글 상세 화면으로 복귀
        return;
    }

    // 삭제 실행
    char query[1000];
    sprintf(query, "DELETE FROM posts WHERE post_id = '%d'", post_id);
    sword ret1 = executeOCIQuery(envhp, svchp, errhp, query);

    clear();
    curs_set(0);
    if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
        mvprintw(10, 10, "게시글 삭제 완료!");
    }
    else {
        mvprintw(10, 10, "게시글 삭제 실패.");
    }

    mvprintw(12, 10, "아무 키나 눌러 뒤로 가기...");
    refresh();
    getch();  // 사용자 입력 대기

    endwin();
    tui_post_list();  // 삭제 후 게시글 목록으로 이동
}


int tui_post_page() {
    int highlight = 0;
    int choice = 0;
    const char* menu[] = {
        "게시판 조회           ",
        "게시글 등록           ",
        "뒤로 가기           "
    };
    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    while (1) {
        clear();
        mvprintw(0, 10, "===== [게시판 페이지] =====");
        for (int i = 0; i < POST_MENU_SIZE; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(i + 2, 10, menu[i]);
            if (i == highlight) attroff(A_REVERSE);
        }
        refresh();
        int key = getch();
        switch (key) {
        case KEY_UP: highlight = (highlight == 0) ? POST_MENU_SIZE - 1 : highlight - 1; break;
        case KEY_DOWN: highlight = (highlight == POST_MENU_SIZE - 1) ? 0 : highlight + 1; break;
        case 10: choice = highlight; break;
        }
        if (key == 10) {
            endwin();
            if (choice == 0) tui_post_list();  // 게시판 조회
            else if (choice == 1) register_post(current_user_uuid);  // 게시글 등록
            else { return 0; }
        }
    }
}
