#pragma once

#ifndef TRADE_H
#define TRADE_H
#include <oci.h>

typedef struct {
    int trade_id;           // 주문 식별자
    char account_id[21];    // 계좌번호 (문자열)
    char ticker[21];        // 티커 코드
    int amount;             // 주문 수량
    int order_price;        // 주문 가격
    // 기타 타임스탬프 등 추가 필드가 필요하면 포함
} OrderRow;

typedef struct {
    int ticker;
    char company_name[50];
    int open_price, high, low;
    double market_cap;
    char stock_date[20];
} StockRow;

typedef struct {
	//long long account_id;
    char account_id[32];
} AccountIDRow;

typedef struct {
    unsigned int state : 2;         // 0: 거래 없음, 1: 부분 체결, 2: 완전 체결, 3: 거래 중단
    unsigned int leftVolume : 30;   // 남은 거래 수량
} TradeStatus; // DB에서 처리하면서 필요 없어짐

int compareBuyOrders(const void* a, const void* b);
sword executeProcessTransactionWithDate();
sword getStockInfo(StockRow** rows);
sword getRandomStockInfo(StockRow** rows);
char* getQueryWithToday(const char* filePath);
sword insertTradeWithDate(char* amount, char* ticker, char* account_id, int order_price);
void stock_order();
//long long getAccountID();
void getAccountID(char* account_id);
int tui_stock_order(int is_random);

#endif // !TRADE_H