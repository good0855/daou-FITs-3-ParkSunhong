DECLARE
  v_today DATE := TO_DATE(:today, 'YYYY-MM-DD');
  
  -- 거래할 Trades 데이터를 가져오는 커서
  CURSOR cur_trades IS
    SELECT t.trade_id,
           t.left_amount,
           t.order_price,
           t.buy_sell,       -- 매도/매수 구분 (0: 매도, 1: 매수)
           t.account_id,     -- 계좌번호
           t.ticker          -- 티커 코드
    FROM Trades t
    JOIN Stocks_Price s ON t.ticker = s.ticker
    WHERE t.trade_success IN (0, 1)
      AND s.stock_date = v_today
      AND t.order_price BETWEEN s.low AND s.high;
      
  l_trade_id     Trades.trade_id%TYPE;
  l_left_amount  Trades.left_amount%TYPE;
  l_order_price  Trades.order_price%TYPE;
  l_buy_sell     Trades.buy_sell%TYPE;
  l_account_id   Trades.account_id%TYPE;
  l_ticker       Trades.ticker%TYPE;
  
  -- Havings 테이블에서 사용할 변수들
  l_quantity         Havings.quantity%TYPE;
  l_purchase_price   Havings.purchase_price%TYPE;
BEGIN
  FOR rec IN cur_trades LOOP
    l_trade_id     := rec.trade_id;
    l_left_amount  := rec.left_amount;
    l_order_price  := rec.order_price;
    l_buy_sell     := rec.buy_sell;
    l_account_id   := rec.account_id;
    l_ticker       := rec.ticker;
    
    -- 거래 내역을 Transactions 테이블에 삽입
    INSERT INTO Transactions (
      transaction_amount, 
      transaction_price, 
      created_at, 
      updated_at, 
      trade_id,
      buy_sell
    )
    VALUES (
      l_left_amount,
      l_order_price,
      SYSDATE,
      SYSDATE,
      l_trade_id,
      l_buy_sell
    );
    
    -- Havings 테이블에 해당 (account_id, ticker)가 존재하는지 확인
    BEGIN
      SELECT quantity, purchase_price
      INTO l_quantity, l_purchase_price
      FROM Havings
      WHERE account_id = l_account_id
        AND ticker = l_ticker;
      
      -- 기존 row가 존재하면 매도/매수에 따라 업데이트
      IF l_buy_sell = 2 THEN
        -- 매도: 보유 수량 및 매입가를 감소시킴
        UPDATE Havings
        SET quantity = quantity - l_left_amount,
            purchase_price = purchase_price - (l_order_price * l_left_amount),
            updated_at = SYSDATE
        WHERE account_id = l_account_id
          AND ticker = l_ticker;
      ELSIF l_buy_sell = 1 THEN
        -- 매수: 보유 수량 및 매입가를 증가시킴
        UPDATE Havings
        SET quantity = quantity + l_left_amount,
            purchase_price = purchase_price + (l_order_price * l_left_amount),
            updated_at = SYSDATE
        WHERE account_id = l_account_id
          AND ticker = l_ticker;
      END IF;
      
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        -- 해당 (account_id, ticker)가 없으면 새로운 row를 삽입
        INSERT INTO Havings (
          account_id, 
          ticker, 
          quantity, 
          purchase_price, 
          created_at, 
          updated_at
        )
        VALUES (
          l_account_id,
          l_ticker,
          CASE 
            WHEN l_buy_sell = 1 THEN l_left_amount    -- 매수 시 양수
            ELSE -l_left_amount                       -- 매도 시 음수
          END,
          CASE 
            WHEN l_buy_sell = 1 THEN l_order_price * l_left_amount     -- 매수 시 양수
            ELSE -l_order_price                        -- 매도 시 음수
          END,
          SYSDATE,
          SYSDATE
        );
    END;
    
    -- 거래가 완료된 경우 Trades 테이블 업데이트 (left_amount를 0, trade_success를 2로 변경)
    UPDATE Trades
    SET left_amount = 0,
        trade_success = 2,
        updated_at = SYSDATE
    WHERE trade_id = l_trade_id;
    
  END LOOP;
  
  COMMIT;
END;
