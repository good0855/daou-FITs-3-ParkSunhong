SELECT
    s.TICKER,
    s.COMPANY_NAME,
    top10.OPEN_PRICE,
    top10.HIGH,
    top10.LOW,
    top10.MARKET_CAP,
    top10.STOCK_DATE
FROM (
    SELECT *
    FROM (
        SELECT
            TICKER,
            OPEN_PRICE,
            HIGH,
            LOW,
            MARKET_CAP,
            STOCK_DATE
        FROM
            STOCKS_PRICE
        WHERE
            STOCK_DATE = TO_DATE(':today', 'YYYYMMDD')
        ORDER BY
            MARKET_CAP DESC
    )
    WHERE ROWNUM <= 10
) top10
JOIN STOCKS s ON top10.TICKER = s.TICKER
