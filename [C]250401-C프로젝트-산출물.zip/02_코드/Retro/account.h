#ifndef ACCOUNT_H
#define ACCOUNT_H
#endif
#define ACCOUNT_MENU_SIZE 4
typedef struct {
	char account_id[30];
	char customer_name[100];
	char password[100];
	int status;
	double interest_rate;
	double balance;
	double total_amount;
} AccountRow;

typedef struct {
	char account_id[30];
	char ticker[30];
	char company_name[50];
	int quantity;
	double market_cap;
	double purchase_price;
	double open_price;
	double high;
	double low;
} MyStockRow;
AccountRow get_account();
void account_password(void (*page_func)());
void account_information();
MyStockRow* get_stocks(int* fetched_count);
void format_date(const char* date_str, char* formatted_date);
void account_stock();
void show_stock_details(MyStockRow* stock);
void deposit();
int tui_account_page();