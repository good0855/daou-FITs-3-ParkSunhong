#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include "test.h" // 테스트용 코드, 코드 작성 시 불필요
#include "db.h"


int main() {
	
	// db 열고 닫기
	init_db();
	//date_test();
	//trade_test();
	//user_login_test();
	loading();
	tui_main_page_test();
	close_db();

	
	return 0;
}