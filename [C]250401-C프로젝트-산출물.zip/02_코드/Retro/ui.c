#include <stdio.h>
#include <curses.h>
#include <oci.h>
#include "ui.h"
#include "user.h"
#include "admin.h"
#include "post.h"
#include "db.h"
#include "account.h"
#include "trade.h"

/*
    Below is TUI page
*/

#define WIDTH  50  // 화면 너비
#define HEIGHT 15  // 화면 높이

void tui_main_page() {
    int highlight = 0;
    int choice = 0;
    const char* menu[] = { "회원가입      ", "로그인       ", "종료       " };

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    start_color();

    // CRT 느낌 색상 설정
    //init_pair(1, COLOR_GREEN, COLOR_BLACK); // 기본 텍스트
    //init_pair(2, COLOR_BLACK, COLOR_GREEN); // 반전 효과
    //init_pair(3, COLOR_CYAN, COLOR_BLACK);  // 박스 테두리

    int start_y = (LINES - HEIGHT) / 2;
    int start_x = (COLS - WIDTH) / 2;
    
    while (1) {
        clear();
        attron(COLOR_PAIR(1));
        if (current_user_uuid == -1 || current_user_type == -1) {
            // 박스 테두리 출력
            mvprintw(start_y, start_x, "╔══════════════════════════════════════════╗");
            mvprintw(start_y + 1, start_x, "║             [ 응답하라 1995 ]            ║");
            mvprintw(start_y + 2, start_x, "╠══════════════════════════════════════════╣");

            for (int i = 0; i < 3; i++) {
                if (i == highlight) attron(COLOR_PAIR(2));
                mvprintw(start_y + 4 + i, start_x + 5, "%s %s", (i == highlight) ? "[>]" : "   ", menu[i]);
                if (i == highlight) attroff(COLOR_PAIR(2));
            }

            mvprintw(start_y + 8, start_x, "╚══════════════════════════════════════════╝");
            refresh();

            int key = getch();
            switch (key) {
            case KEY_UP: highlight = (highlight == 0) ? 2 : highlight - 1; break;
            case KEY_DOWN: highlight = (highlight == 2) ? 0 : highlight + 1; break;
            case 10: choice = highlight; break;
            }

            if (key == 10) {
                endwin();
                if (choice == 0) tui_signin();
                else if (choice == 1) tui_login();
                else { printf("프로그램을 종료합니다.\n"); return; }
            }
        }
        else {
            // whether user is normal or admin
            int result = (current_user_type == 0) ? tui_user_page() : tui_admin_page();
            if (result == 0) continue;  // if logout => go to main page
        }
    }
}

// [Depth 1] Main Page
//void tui_main_page() {
//    int highlight = 0;
//    int choice = 0;
//    // space를 해야 일단 한글이 정상 반전된다
//    const char* menu[] = { 
//        "1. 회원가입    ",
//        "2. 로그인     ",
//        "3. 종료      " };
//
//    initscr();
//    noecho();
//    keypad(stdscr, TRUE);
//    curs_set(0);
//
//    while (1) {
//
//        clear();
//        if (current_user_uuid == -1 || current_user_type == -1) {
//            mvprintw(0, 10, "===== [응답하라 1995] =====");
//            for (int i = 0; i < 3; i++) {
//                if (i == highlight) attron(A_REVERSE);
//                mvprintw(i + 2, 10, menu[i]);
//                if (i == highlight) attroff(A_REVERSE);
//            }
//            refresh();
//
//            int key = getch();
//            switch (key) {
//            case KEY_UP: highlight = (highlight == 0) ? 2 : highlight - 1; break;
//            case KEY_DOWN: highlight = (highlight == 2) ? 0 : highlight + 1; break;
//            case 10: choice = highlight; break;
//            }
//
//            if (key == 10) {
//                endwin();
//                if (choice == 0) tui_signin();
//                else if (choice == 1) tui_login();
//                else { printf("프로그램을 종료합니다.\n"); return; }
//            }
//
//        }
//        else {
//            // whether user is normal or admin
//            int result = (current_user_type == 0) ? tui_user_page() : tui_admin_page();
//            if (result == 0) continue;  // if logout => go to main page
//        }
//
//        
//    }
//}

// [Depth 2] User Page
int tui_user_page() {
    int highlight = 0;
    int choice = 0;
    const char* menu[] = { 
        "게시판 입장            ",
        "내 계좌 확인           ", 
        "주식 주문              ",
        "로그아웃 및 종료        " };

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    while (1) {
        clear();
        mvprintw(0, 10, "===== [User Page] =====");
        for (int i = 0; i < USER_MENU_SIZE; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(i + 2, 10, menu[i]);
            if (i == highlight) attroff(A_REVERSE);
        }
        refresh();

        int key = getch();
        switch (key) {
        case KEY_UP: highlight = (highlight == 0) ? USER_MENU_SIZE - 1 : highlight - 1; break;
        case KEY_DOWN: highlight = (highlight == USER_MENU_SIZE - 1) ? 0 : highlight + 1; break;
        case 10: choice = highlight; break;
        case KEY_LEFT: endwin(); return 0;
        }

        if (key == 10) {
            endwin();
            if (choice == 0) tui_post_page();
            else if (choice == 1) tui_account_page();  // 계좌 확인 함수 호출
            else if (choice == 2) tui_stock_order(0);  // 주식 주문 함수 호출
            else { logout(); return 0; }
        }
    }
}

// [Depth 2] Admin Page
int tui_admin_page() {
    int highlight = 0;
    int choice = 0;
    const char* menu[] = { 
        "1. 금지어 관리             ",
        "2. 게시글 관리             ", 
        "3. 계좌 동결               ", 
        "4. 주식 보유 현황 보고서 저장             ", 
        "5. 거래일자 설정             ", 
        "6. 로그아웃 및 종료        " };

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);

    while (1) {
        clear();
        mvprintw(0, 10, "===== [Admin Page] =====");
        for (int i = 0; i < ADMIN_MENU_SIZE; i++) {
            if (i == highlight) attron(A_REVERSE);
            mvprintw(i + 2, 10, menu[i]);
            if (i == highlight) attroff(A_REVERSE);
        }
        refresh();

        int key = getch();
        switch (key) {
        case KEY_UP: highlight = (highlight == 0) ? ADMIN_MENU_SIZE - 1 : highlight - 1; break;
        case KEY_DOWN: highlight = (highlight == ADMIN_MENU_SIZE - 1) ? 0 : highlight + 1; break;
        case 10: choice = highlight; break;
        case KEY_LEFT: endwin(); return 0;
        }

        if (key == 10) {
            endwin();
            if (choice == 0) tui_banned_word_page();
            else if (choice == 1) tui_admin_post_list();  // 게시글 관리 함수 호출
            else if (choice == 2) tui_freeze_account_page();  // 계좌 동결 함수 호출
            else if (choice == 3) save_stocks_to_json();  // 계좌 동결 함수 호출
            else if (choice == 4) set_next_day();  // 거래 일자 설정
            else { logout(); return 0; }
        }
    }
}

// 비밀번호 *로 치환
void get_masked_input(int y, int x, char* buffer, size_t size) {
    move(y, x);
    int index = 0;
    int ch;
    while ((ch = getch()) != '\n' && index < size - 1) {
        if (ch == KEY_BACKSPACE || ch == 127) { // 백스페이스 처리
            if (index > 0) {
                index--;
                mvprintw(y, x + index, " ");
                move(y, x + index);
                refresh();
            }
        }
        else {
            buffer[index++] = ch;
            mvprintw(y, x + index - 1, "*");
            refresh();
        }
    }
    buffer[index] = '\0';
}

// 로그인 페이지
void tui_login() {
    LoginInfo login_info;
    char query_select[512];

    initscr();
    noecho();
    keypad(stdscr, TRUE);
    

    while (1) {
        curs_set(1);
        clear();
        mvprintw(0, 10, "===== [로그인] =====");

        mvprintw(2, 10, "id: ");
        move(2, 20); // move cursor
        echo();
        char customer_id[100];
        getstr(customer_id);
        customer_id[strcspn(customer_id, "\n")] = '\0';
        strncpy(login_info.customer_id, customer_id, sizeof(login_info.customer_id) - 1);

        mvprintw(3, 10, "password: ");
        noecho();
        char customer_pw[100];
        get_masked_input(3, 20, customer_pw, sizeof(customer_pw));
        strncpy(login_info.customer_pw, customer_pw, sizeof(login_info.customer_pw) - 1);

        snprintf(query_select, sizeof(query_select),
            "SELECT customer_uuid, customer_type FROM customers WHERE customer_id = '%s' AND customer_pw = '%s'",
            login_info.customer_id, login_info.customer_pw);
        CustomerRow row = { 0 };
        FieldMapping mappings[] = {
            { offsetof(CustomerRow, customer_uuid), TYPE_INT, 0 },
            { offsetof(CustomerRow, customer_type), TYPE_INT, 0 }
        };
        int num_fields = sizeof(mappings) / sizeof(FieldMapping);

        sword ret = executeSelectWithMapping(envhp, svchp, errhp, query_select, &row, mappings, num_fields);

        if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
            mvprintw(5, 10, "로그인 성공!");
            current_user_uuid = row.customer_uuid;
            current_user_type = row.customer_type;
            mvprintw(7, 10, "계속하려면 아무 키나 누르세요...");
            refresh();
            getch();
            break;  // 로그인 성공 시 종료
        }
        else {
            mvprintw(5, 10, "로그인에 실패하였습니다.");
            int highlight = 0; // 0: 다시 로그인, 1: 종료
            int break_status = 0; // 재 로그인을 위한 코드
            while (break_status == 0) {
                clear();  // 화면을 지워서 다시 그리기
                mvprintw(0, 10, "===== [로그인 실패] =====");
                curs_set(0); // 커서 초기화

                if (highlight == 0) attron(A_REVERSE);
                mvprintw(7, 10, "다시 로그인      ");
                attroff(A_REVERSE);

                if (highlight == 1) attron(A_REVERSE);
                mvprintw(7, 30, "종료      ");
                attroff(A_REVERSE);

                refresh();

                int key = getch();
                switch (key) {
                case KEY_LEFT:  highlight = (highlight == 0) ? 1 : 0; break;
                case KEY_RIGHT: highlight = (highlight == 1) ? 0 : 1; break;
                case 10: // Enter 입력
                    if (highlight == 0) {
                        break_status = 1;
                        break;  // 다시 로그인 선택 시 계속해서 로그인 시도
                    }
                    else {
                        mvprintw(9, 10, "로그인 종료.\n");
                        refresh();
                        //getch();
                        //endwin();  // 종료
                        return;
                    }
                }
            }
            clear();
            continue;
        }
    }
    endwin();
}

// 회원가입 페이지
void tui_signin() {
    SignInfo new_user;
    char query_insert[512];

    initscr();
    noecho();
    keypad(stdscr, TRUE);

    while (1) {
        curs_set(1);
        clear();
        mvprintw(0, 10, "===== [회원가입] =====");

        mvprintw(2, 10, "아이디: ");
        move(2, 20); // 커서 위치
        echo();
        char customer_id[100];
        getstr(customer_id);
        customer_id[strcspn(customer_id, "\n")] = '\0';
        strncpy(new_user.customer_id, customer_id, sizeof(new_user.customer_id) - 1);

        mvprintw(3, 10, "비밀번호: ");
        noecho();
        char customer_pw[100];
        get_masked_input(3, 20, customer_pw, sizeof(customer_pw));
        strncpy(new_user.customer_pw, customer_pw, sizeof(new_user.customer_pw) - 1);

        mvprintw(4, 10, "이름: ");
        move(4, 20);
        echo();
        char customer_name[100];
        getstr(customer_name);
        customer_name[strcspn(customer_name, "\n")] = '\0';
        strncpy(new_user.customer_name, customer_name, sizeof(new_user.customer_name) - 1);

        mvprintw(5, 10, "계좌 비밀번호 (4자리 숫자): ");
        noecho();
        int account_password;
        scanw("%d", &account_password);
        new_user.account_password = account_password;

        // 회원가입 쿼리 실행
        snprintf(query_insert, sizeof(query_insert),
            "INSERT INTO customers (customer_id, customer_pw, customer_name) VALUES ('%s', '%s', '%s')",
            new_user.customer_id, new_user.customer_pw, new_user.customer_name);

        sword ret1 = executeOCIQuery(envhp, svchp, errhp, query_insert);
  
        if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
            mvprintw(7, 10, "회원가입 성공!");
            // 계좌 개설 함수 호출
            open_account(&new_user);

            mvprintw(8, 10, "계속하려면 아무 키나 누르세요...");
            refresh();
            getch();
            break;  // 회원가입 성공 시 종료
        }
        else {
            int highlight = 0; // 0: 다시 로그인, 1: 종료
            int break_status = 0; // 재 로그인을 위한 코드
            while (break_status == 0) {
                clear();  // 화면을 지워서 다시 그리기
                mvprintw(0, 10, "ID 중복으로 회원가입에 실패하였습니다.");
                curs_set(0); // 커서 초기화

                if (highlight == 0) attron(A_REVERSE);
                mvprintw(7, 10, "다시 시도      ");
                attroff(A_REVERSE);

                if (highlight == 1) attron(A_REVERSE);
                mvprintw(7, 30, "종료      ");
                attroff(A_REVERSE);

                refresh();

                int key = getch();
                switch (key) {
                case KEY_LEFT:  highlight = (highlight == 0) ? 1 : 0; break;
                case KEY_RIGHT: highlight = (highlight == 1) ? 0 : 1; break;
                case 10: // Enter 입력
                    if (highlight == 0) {
                        break_status = 1;
                        break;  // 다시 로그인 선택 시 계속해서 로그인 시도
                    }
                    else {
                        mvprintw(9, 10, "회원가입 종료.\n");
                        refresh();
                        //getch();
                        //endwin();  // 종료
                        return;
                    }
                }
            }
            clear();    
            continue;
        }

    }
    endwin();
}



#include <curses.h>
#include <time.h>  // nanosleep() 사용

void delay(int milliseconds) {
    clock_t start_time = clock();
    while (clock() < start_time + milliseconds * (CLOCKS_PER_SEC / 1000));
}

const char* ascii_art[] = {
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",

    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "───────────────────────────────────────────░░───────────────",
    "────────────────────────────────────────░░░░░───────────────",
    "─────────────────────────────────────░░░░░░░░───────────────",
    "──────────────────────────────────░░░░░░░░░░░───────────────",
    "────────────────────────────────░░░░░░░░░░░░────────────────",
    "─────────────────────────────░░░░░░░░░░░░░░░────────────────",
    "──────────────────────────░░░░░░░░░░░░░░░░░░────────────────",
    "─────────────────────────░░░░░░░░░░░░░░░░░░░────────────────",
    "────────────────────────────░░░░░░░░░░░░░░░░────────────────",
    "──────────────────────────────░░░░░░░░░░░░░─────────────────",
    "──────────────────▓▓▓▓▓▓▓──────░░░░░░░░░░░░─────────────────",
    "──────────────────▓▓▓▓▓▓▓─────░░░░░░░░░░░░░─────────────────",
    "──────────────────▓▓▓▓▓▓▓─────░░░░░░░░░░░░░─────────────────",
    "──────────────────▓▓▓▓▓▓▓────░░░░░░░░░░░░░░─────────────────",
    "──────────────────▓▓▓▓▓▓▓───░░░░░░░░░░░░░░░─────────────────",
    "──────────────────▓▓▓▓▓▓▓──░░░░░░░░░─░░░░░──────────────────",
    "──────────────────▓▓▓▓▓▓▓─░░░░░░░░░───░░░░──────────────────",
    "──────────────────▓▓▓▓▓▓▓░░░░░░░░░─────░░░──────────────────",
    "──────────────────▓▓▓▓▓▓▓░░░░░░░░░─────░░░──────────────────",
    "──────────────────▓▓▓▓▓▓░░░░░░░░░───────░░──────────────────",
    "──────────────────▓▓▓▓▓▓░░░░░░░░────────░───────────────────",
    "──────────────────▓▓▓▓▓▓▓░░░░░░─────────────────────────────",
    "──────────────────▓▓▓▓▓▓▓▓░░░░▓▓░───────────────────────────",
    "──────────────────▓▓▓▓▓▓▓▓▓▒░▓▓▓▓───────────────────────────",
    "──────────────────▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓───────────────────────────",
    "──────────────────▓▓▓▓▓▓▓─▓▓▓▓▓▓▓▓──────────────────────────",
    "──────────────────▓▓▓▓▓▓▓─░▓▓▓▓▓▓▓▓─────────────────────────",
    "──────────────────▓▓▓▓▓▓▓──▓▓▓▓▓▓▓▓─────────────────────────",
    "──────────────────▓▓▓▓▓▓▓───▓▓▓▓▓▓▓▓────────────────────────",
    "──────────────────▓▓▓▓▓▓▓───░▓▓▓▓▓▓▓▓───────────────────────",
    "──────────────────▓▓▓▓▓▓▓────▓▓▓▓▓▓▓▓░──────────────────────",
    "──────────────────▓▓▓▓▓▓▓─────▓▓▓▓▓▓▓▓──────────────────────",
    "──────────────────▓▓▓▓▓▓▓─────░▓▓▓▓▓▓▓▓─────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────",
    "────────────────────────────────────────────────────────────"
};

void draw_ascii_art(WINDOW* win) {
    int start_y = 1;
    for (int i = 0; i < sizeof(ascii_art) / sizeof(ascii_art[0]); i++) {
        mvwprintw(win, start_y + i, 2, "%s", ascii_art[i]);
    }
}

/*
    loading page
*/

void draw_loading_bar() {
    int total = 50;  // 로딩 바 길이
    for (int i = 0; i <= total; i++) {
        printf("\r[");
        for (int j = 0; j < total; j++) {
            if (j < i)
                printf("=");
            else
                printf(" ");
        }
        printf("] %d%%", i * 2);  // 퍼센트 표시
        fflush(stdout);  // 즉시 출력
        delay(30);  // 100ms 대기
    }
    printf("\n");
}

void loading() {

    for (int i = 0; i < sizeof(ascii_art) / sizeof(ascii_art[0]); i++) {
        printf("%s\n", ascii_art[i]);
        delay(30);
    }
    draw_loading_bar();
    system("cls");  // 콘솔 클리어

}



