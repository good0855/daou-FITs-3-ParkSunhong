#pragma once

#ifndef UTIL_H
#define UTIL_H

int dateIndex;
char thisYear[5];
char dateArr[1000];

void initDate();
void getDate(char* date);
void dayPass();
#endif