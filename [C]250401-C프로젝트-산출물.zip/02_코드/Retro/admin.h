#pragma once

#ifndef ADMIN
#define ADMIN
#endif

#include <oci.h>
#include "user.h"

#define ADMIN_MAX_BANNED_WORD_LENGTH 30

// banned word dto
typedef struct {
	long admin_uuid;
	char banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];
} BannedWordInfo;

// banned word vo
typedef struct {
	long customer_uuid;
	char banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];

} BannedWordRow;

// banned word vo -> tui 출력용
typedef struct {
	long word_id;
	long customer_uuid;
	char customer_id[CUSTOMER_MAX_ID_LENGTH]; // 아이디
	char customer_name[CUSTOMER_MAX_NAME_LENGTH]; // 이름
	char banned_word[ADMIN_MAX_BANNED_WORD_LENGTH];
} BannedWordListRow;

// tui 출력용 account list
typedef struct {
	char account_id[ACCOUNT_NUMBER_LENGTH+1];
	long customer_uuid;
	char customer_id[CUSTOMER_MAX_ID_LENGTH]; // 아이디
	char customer_name[CUSTOMER_MAX_NAME_LENGTH]; // 이름
	long total_amount; // 총 자산
	double interest_rate; // 수익률
	int status; // 계좌 상태(0 : 정상, 1 : 정지)
} AccountListRow;

// json 파일 저장
typedef struct {
	char customer_name[100];
	char company_name[50];
	double purchase_price;
} StockJsonRow;

void save_stocks_to_json();

// banned word sub page UI
void banned_word_page();


/*
	Below is the OCI function for connecting with DB
*/
void select_banned_words();

sword insert_banned_words(char* word);

sword delete_banned_word(int word_id);

void tui_select_banned_words(BannedWordListRow** rows, int* num_rows);

/*
	TUI

*/
// Y/N 선택 모달창을 띄우는 함수
int tui_show_YN_modal(const char* message);

// 금지어 관리 메인 페이지
void tui_banned_word_page(void);

// 금지어 목록을 보여주는 함수
void tui_show_banned_words(BannedWordListRow* bannedWordList, int num_rows);


// 금지어 추가 페이지
void tui_insert_banned_words(void);

// 금지어 삭제 함수
int tui_delete_banned_words(long word_id);

/*
	[계좌 동결]
*/
void tui_freeze_account_page();

void tui_select_accounts(AccountListRow** rows, int* num_rows);

sword update_account_status(const char* account_id, int new_status);

void set_next_day();

void tui_admin_post_list();

int tui_admin_detail_post(int index);

void admin_delete_post(int post_id, int index);