#include <stdio.h>
#include <string.h>
#include <time.h>
#include "user.h"
#include "db.h"

// -1 : null
long current_user_uuid = -1;
int current_user_type = -1;


// 회원가입 함수
void signin() {
    SignInfo new_user;

    printf("회원가입을 진행합니다.\n");

    // 사용자 입력 받기
    printf("아이디 입력: ");
    scanf_s("%s", new_user.customer_id, (unsigned int)sizeof(new_user.customer_id));

    printf("비밀번호 입력: ");
    scanf_s("%s", new_user.customer_pw, (unsigned int)sizeof(new_user.customer_pw));

    printf("이름 입력: ");
    scanf_s("%s", new_user.customer_name, (unsigned int)sizeof(new_user.customer_name));

    printf("계좌 비밀번호 입력 (숫자 4자리): ");
    scanf_s("%d", &new_user.account_password);

    // 회원가입 쿼리 실행
    char query_insert[512];
    snprintf(query_insert, sizeof(query_insert),
        "INSERT INTO customers (customer_id, customer_pw, customer_name) VALUES ('%s', '%s', '%s')",
        new_user.customer_id, new_user.customer_pw, new_user.customer_name);

    sword ret1 = executeOCIQuery(envhp, svchp, errhp, query_insert);

    if (ret1 == OCI_SUCCESS || ret1 == OCI_SUCCESS_WITH_INFO) {
        printf("%s\n\n", "회원가입 성공");
        // 계좌개설
        open_account(&new_user);
    }
    else {
        printf("%s\n\n", "회원가입 실패");
    }


}

// 고유 계좌번호 생성 함수
static void generate_account_number(char* account_number) {
    srand(time(NULL) ^ (getpid() << 16));  // 시드값을 시간과 프로세스 ID로 설정

    // 첫 4자리는 "1001"로 고정
    snprintf(account_number, 5, "1001");

    // rand()를 한 번만 호출하여 고유 숫자 추출
    unsigned long long rand_value = ((unsigned long long)rand() << 32) | rand();

    // rand_value의 마지막 16자리만 사용하여 계좌번호 생성
    for (int i = 4; i < ACCOUNT_NUMBER_LENGTH; i++) {
        account_number[i] = '0' + (rand_value % 10);  // 0-9 사이의 숫자만 사용
        rand_value /= 10;  // 다음 자리수를 위해 나누기
    }

    account_number[ACCOUNT_NUMBER_LENGTH] = '\0';  // 문자열 끝에 널 문자 추가
}

// 계좌개설 함수
void open_account(SignInfo* new_user) {
    char account_id[ACCOUNT_NUMBER_LENGTH + 1];  // 20자리 + null 종료 문자
    char query_select[512];
    char query_insert[512];

    // 1. 계좌번호 생성 함수 호출
    generate_account_number(account_id);

    // 2. 고객 UUID 가져오기 위한 SELECT 쿼리 준비
    snprintf(query_select, sizeof(query_select),
        "SELECT customer_uuid FROM customers where customer_id = '%s'",
        new_user->customer_id);

    // 결과를 저장할 구조체
    CustomerRow row = { 0 };

    FieldMapping mappings[] = {
        { offsetof(CustomerRow, customer_uuid), TYPE_INT, 0 }
    };
    int num_fields = sizeof(mappings) / sizeof(FieldMapping);

    sword ret = executeSelectWithMapping(envhp, svchp, errhp, query_select, &row, mappings, num_fields);

    // 3. 계좌 등록
    snprintf(query_insert, sizeof(query_insert),
        "INSERT INTO accounts (account_id, customer_uuid, password) VALUES ('%s', '%ld', '%d')",
        account_id, row.customer_uuid, new_user->account_password);

    sword ret1 = executeOCIQuery(envhp, svchp, errhp, query_insert);

    if (ret1 == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
        printf("%s\n\n", "계좌 등록 성공");
    }
    else {
        printf("%s\n\n", "계좌 등록 실패");
    }
}

// 로그인 함수
void login() {
    LoginInfo login_info;
    char query_select[512];
    int choice;

    while (1) {  // 무한 루프 (로그인 성공하거나 종료를 선택할 때까지 반복)
        printf("로그인을 진행합니다.\n");

        // 사용자 입력 받기
        printf("아이디 입력: ");
        scanf_s("%s", login_info.customer_id, (unsigned int)sizeof(login_info.customer_id));

        printf("비밀번호 입력: ");
        scanf_s("%s", login_info.customer_pw, (unsigned int)sizeof(login_info.customer_pw));

        // 고객 ID와 비밀번호를 가져오기 위한 SELECT 쿼리 준비
        snprintf(query_select, sizeof(query_select),
            "SELECT customer_uuid, customer_type FROM customers WHERE customer_id = '%s' AND customer_pw = '%s'",
            login_info.customer_id, login_info.customer_pw);
        // 결과를 저장할 구조체
        CustomerRow row = { 0 };

        FieldMapping mappings[] = {
            { offsetof(CustomerRow, customer_uuid), TYPE_INT, 0 },
            { offsetof(CustomerRow, customer_type), TYPE_INT, 0 }
        };
        int num_fields = sizeof(mappings) / sizeof(FieldMapping);

        // SELECT 쿼리 실행
        sword ret = executeSelectWithMapping(envhp, svchp, errhp, query_select, &row, mappings, num_fields);

        // 결과 확인
        if (ret == OCI_SUCCESS || ret == OCI_SUCCESS_WITH_INFO) {
            // 로그인 성공
            printf("로그인 성공!\n");
            current_user_uuid = row.customer_uuid;  // 로그인한 사용자 UUID 저장
            current_user_type = row.customer_type;  // 로그인한 사용자 타입(0: 일반 유저, 1: 관리자)
            break;  // 로그인 성공 시 루프 종료
        }
        else {
            // 아이디나 비밀번호가 일치하지 않으면 로그인 실패
            printf("아이디나 비밀번호가 일치하지 않습니다.\n");
        }

        // 로그인 실패 후 재시도 또는 종료 선택
        printf("\n1. 다시 로그인\n2. 종료\n선택: ");
        scanf_s("%d", &choice);

        if (choice == 2) {
            printf("로그인 종료.\n");
            break;  // 종료를 선택하면 루프 종료
        }
    }
}

// 로그아웃 함수
void logout() {
    current_user_uuid = -1;
    current_user_type = -1;
    printf("성공적으로 로그아웃하였습니다.\n");
}