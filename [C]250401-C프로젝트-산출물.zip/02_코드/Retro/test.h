#pragma once
#ifndef TEST_H
#define TEST_H

int user_test();
int trade_test();
//int post_test();
int trade_test();
void date_test();
void tui_main_page_test();
void tui_user_page_test();

#endif