#define _CRT_SECURE_NO_WARNINGS
#include "util.h"
#include "trade.h"
#include <stdio.h>
#include <string.h>

extern int dateIndex;
extern char thisYear[5];
extern char dateArr[1000];

void initDate() {
#ifndef INIT_DATE
#define INIT_DATE
	// ./util/market_open_date.txt 파일을 읽어서 dateArr에 저장
	FILE* fp = fopen("./util/market_open_date.txt", "r");
	if (fp == NULL) {
		printf("market_open_date.txt 파일을 읽을 수 없습니다.\n");
		return;
	}
	// 첫줄은 dateIndex, 둘째줄은 thisYear, 셋째줄은 dateArr
	fscanf(fp, "%d", &dateIndex);
	fscanf(fp, "%s", thisYear);
	fscanf(fp, "%s", dateArr);
	fclose(fp);
#endif
}

void getDate(char* date) {
	initDate();
	// dateArr[dateIndex]를 date에 복사
	strcpy(date, thisYear);
	// dateArr[4*dateIndex]부터 dateArr[4*dateIndex+3]까지 date에 복사
	strncat(date, dateArr + 4 * dateIndex, 4);
}
void dayPass() {
	initDate();
	if (thisYear && dateArr) {
		// dateIndex를 1 증가
		dateIndex++;
		// 파일에 dateIndex를 저장
		FILE* fp = fopen("./util/market_open_date.txt", "w");
		if (fp == NULL) {
			printf("market_open_date.txt 파일을 열 수 없습니다.\n");
			return;
		}
		fprintf(fp, "%d\n", dateIndex);
		fprintf(fp, "%s\n", thisYear);
		fprintf(fp, "%s\n", dateArr);
		fclose(fp);

		// transactions 처리
		executeProcessTransactionWithDate();
	}
	else printf("날짜 정보가 초기화되지 않았습니다.\n");
}