#ifndef POST_H
#define POST_H
#define MAX_POSTS 100
#endif
typedef struct {
	int post_id;
	int customer_uuid;
	char customer_name[100];
	char title[100];
	char content[1000];
	char created_at[100];
} PostRow;
#define POST_MENU_SIZE 3
void register_post(int customer_uuid);
void tui_post_list();
PostRow* getPost(int* fetched_count);
int contains_banned_word(const char* text);
void update_post(PostRow selected_post, int index);
void delete_post(int post_id, int index);
void get_banned_words();
int tui_post_page();
int tui_detail_post(int index);
//int tui_post_by_id(int post_id);