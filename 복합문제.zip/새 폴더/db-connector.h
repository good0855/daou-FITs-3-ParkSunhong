#pragma once
#ifndef DB_CONNECTOR_H
#define DB_CONNECTOR_H

#include <oci.h>
#include "stock.h"

extern long transaction_id;
extern OCIEnv* envhp;
extern OCIError* errhp;
extern OCISvcCtx* svchp;
extern OCISession* usrhp;
extern OCIServer* srvhp;

// Function declarations
void check_error(OCIError* errhp);
int connect_to_db(const char* username, const char* password, const char* dbname);
long init_transaction_id();
void insert_data(const Transaction* transaction);
void select_data();
void update_data_by_transaction_id(long transaction_id, long new_transaction_amount, double new_transaction_price);
void select_data_by_customer_name(const char* customer_name_input);

#endif // DB_CONNECTOR_H
