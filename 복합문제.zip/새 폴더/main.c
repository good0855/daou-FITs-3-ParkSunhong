﻿#include <stdio.h>
#include <oci.h>
#include "db-connector.h"
#include "stock.h"

long transaction_id;

int main() {


    // DB 연결
    if (connect_to_db("C##DEV", "1234", "localhost:1521/xe") != OCI_SUCCESS) {
        printf("DB 연결 실패\n");
        return -1;
    }
    printf("Oracle DB 연결 성공!\n");

    transaction_id = init_transaction_id();

    // 출력
    print_page();

    return 0;
}