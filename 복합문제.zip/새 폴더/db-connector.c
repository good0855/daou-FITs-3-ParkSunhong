﻿#define _CRT_SECURE_NO_WARNINGS
#include <oci.h>
#include <stdlib.h> 
#include <stdio.h>
#include "stock.h"
#include "db-connector.h"

extern long transaction_id;

OCIEnv* envhp;
OCIError* errhp;
OCISvcCtx* svchp;
OCISession* usrhp;
OCIServer* srvhp;

// 에러 처리 함수
void check_error(OCIError* errhp) {
    text errbuf[512];
    sb4 errcode = 0;
    OCIErrorGet(errhp, 1, NULL, &errcode, errbuf, sizeof(errbuf), OCI_HTYPE_ERROR);
    printf("Oracle Error: %s\n", errbuf);
}

// DB 연결 함수
int connect_to_db(const char* username, const char* password, const char* dbname) {

        // OCI 환경 초기화
    OCIEnvCreate(&envhp, OCI_DEFAULT, NULL, NULL, NULL, NULL, 0, NULL);
    OCIHandleAlloc(envhp, (void**)&errhp, OCI_HTYPE_ERROR, 0, NULL);
    OCIHandleAlloc(envhp, (void**)&svchp, OCI_HTYPE_SVCCTX, 0, NULL);
    OCIHandleAlloc(envhp, (void**)&usrhp, OCI_HTYPE_SESSION, 0, NULL);
    OCIHandleAlloc(envhp, (void**)&srvhp, OCI_HTYPE_SERVER, 0, NULL);

    // 서버 연결
    OCIServerAttach(srvhp, errhp, (OraText*)dbname, strlen(dbname), OCI_DEFAULT);

    // 서비스 컨텍스트에 서버 설정
    OCIAttrSet(svchp, OCI_HTYPE_SVCCTX, srvhp, 0, OCI_ATTR_SERVER, errhp);

    // 사용자 세션 설정
    OCIAttrSet(usrhp, OCI_HTYPE_SESSION, username, strlen(username), OCI_ATTR_USERNAME, errhp);
    OCIAttrSet(usrhp, OCI_HTYPE_SESSION, password, strlen(password), OCI_ATTR_PASSWORD, errhp);

    // 세션 시작
    OCISessionBegin(svchp, errhp, usrhp, OCI_CRED_RDBMS, OCI_DEFAULT);
    OCIAttrSet(svchp, OCI_HTYPE_SVCCTX, usrhp, 0, OCI_ATTR_SESSION, errhp);

    return OCI_SUCCESS;
}


// 자동으로 TRANSACTION_ID 초기화해주는 것
long init_transaction_id() {
    OCIStmt* stmthp;
    OCIDefine* def1 = NULL;
    long transaction_id = 0;  // 기본값 (값이 없을 경우 0)

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);


    // SQL 쿼리 수정: MAX 값을 가져오되, NULL일 경우 0을 반환하도록 NVL 사용
    char* select_sql = "SELECT NVL(MAX(TRANSACTION_ID), 0) AS TRANSACTION_ID FROM TRANSACTIONS";

    OCIStmtPrepare(stmthp, errhp, (text*)select_sql, strlen(select_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    OCIStmtExecute(svchp, stmthp, errhp, 0, 0, NULL, NULL, OCI_DEFAULT);

    OCIDefineByPos(stmthp, &def1, errhp, 1, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);

    sword status;
    while ((status = OCIStmtFetch2(stmthp, errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT)) == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
    }


    return transaction_id;
}


// 데이터 삽입 함수
void insert_data(const Transaction* transaction) {
    OCIStmt* stmthp;
    OCIBind* bnd1 = NULL, * bnd2 = NULL, * bnd3 = NULL, * bnd4 = NULL, * bnd5 = NULL, * bnd6 = NULL;
    /*** 데이터 삽입 (INSERT) ***/
    char* insert_sql = "INSERT INTO TRANSACTIONS (TRANSACTION_ID, CUSTOMER_NAME, STOCK_NAME, TRANSACTION_TYPE, TRANSACTION_AMOUNT, TRANSACTION_PRICE) VALUES (:1, :2, :3, :4, :5, :6)";

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(stmthp, errhp, (text*)insert_sql, strlen(insert_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd1, errhp, 1, &transaction->transaction_id, sizeof(transaction->transaction_id), SQLT_INT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd1, errhp, 2, transaction->customer_name, sizeof(transaction->customer_name), SQLT_STR, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd3, errhp, 3, transaction->stock_name, sizeof(transaction->stock_name), SQLT_STR, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd4, errhp, 4, &transaction->transaction_type, sizeof(transaction->transaction_type), SQLT_INT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd5, errhp, 5, &transaction->transaction_amount, sizeof(transaction->transaction_amount), SQLT_INT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd6, errhp, 6, &transaction->transaction_price, sizeof(transaction->transaction_price), SQLT_FLT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);

    if (OCIStmtExecute(svchp, stmthp, errhp, 1, 0, NULL, NULL, OCI_COMMIT_ON_SUCCESS) != OCI_SUCCESS) {
        check_error(errhp);
    }
    else {
        printf("✅ 데이터 삽입 완료!\n");
    }
}

// 데이터 조회 함수
void select_data() {
    OCIStmt* stmthp;
    OCIDefine* def1 = NULL, * def2 = NULL, * def3 = NULL, * def4 = NULL, * def5 = NULL, * def6 = NULL;
    char* select_sql = "SELECT TRANSACTION_ID, CUSTOMER_NAME, STOCK_NAME, TRANSACTION_TYPE, TRANSACTION_AMOUNT, TRANSACTION_PRICE FROM TRANSACTIONS ORDER BY TRANSACTION_ID";
    long transaction_id;
    char customer_name[MAX_CUSTOMER_NAME_LENGTH];
    char stock_name[MAX_STOCK_NAME_LENGTH];
    int transaction_type;
    long transaction_amount;
    double transaction_price;

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(stmthp, errhp, (text*)select_sql, strlen(select_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    OCIStmtExecute(svchp, stmthp, errhp, 0, 0, NULL, NULL, OCI_DEFAULT);

    OCIDefineByPos(stmthp, &def1, errhp, 1, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def2, errhp, 2, customer_name, sizeof(stock_name), SQLT_STR, NULL, NULL, NULL, OCI_DEFAULT);

    OCIDefineByPos(stmthp, &def3, errhp, 3, stock_name, sizeof(stock_name), SQLT_STR, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def4, errhp, 4, &transaction_type, sizeof(transaction_type), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def5, errhp, 5, &transaction_amount, sizeof(transaction_amount), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def6, errhp, 6, &transaction_price, sizeof(transaction_price), SQLT_FLT, NULL, NULL, NULL, OCI_DEFAULT);

    printf("✅ 테이블 조회 결과:\n");
    printf("------------------------------------------------------------------------\n");
    printf("| TRANSACTION_ID | CUSTOMER_NAME | STOCK_NAME | TRANSACTION_TYPE | TRANSACTION_AMOUNT | TRANSACTION_PRICE |\n");
    printf("------------------------------------------------------------------------\n");

    sword status;
    while ((status = OCIStmtFetch2(stmthp, errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT)) == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        printf("| %-15ld | %-10s | %-10s | %-15d | %-18ld | %-17.2f |\n", transaction_id, customer_name, stock_name, transaction_type, transaction_amount, transaction_price);
    }
    printf("------------------------------------------------------------\n");
}

// 데이터 수정 함수
void update_data_by_transaction_id(long transaction_id, long new_transaction_amount, double new_transaction_price) {
    OCIStmt* stmthp;
    OCIBind* bnd1 = NULL, * bnd2 = NULL, * bnd3 = NULL;

    // 올바른 UPDATE SQL 쿼리
    char* update_sql = "UPDATE TRANSACTIONS SET TRANSACTION_AMOUNT = :1, TRANSACTION_PRICE = :2 WHERE TRANSACTION_ID = :3";

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(stmthp, errhp, (text*)update_sql, strlen(update_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);

    // 바인딩: 새로운 값 적용
    OCIBindByPos(stmthp, &bnd1, errhp, 1, &new_transaction_amount, sizeof(new_transaction_amount), SQLT_INT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd2, errhp, 2, &new_transaction_price, sizeof(new_transaction_price), SQLT_FLT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);
    OCIBindByPos(stmthp, &bnd3, errhp, 3, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);

   
    // SQL 실행 및 예외 처리
    if (OCIStmtExecute(svchp, stmthp, errhp, 1, 0, NULL, NULL, OCI_COMMIT_ON_SUCCESS) != OCI_SUCCESS) {
        check_error(errhp);
        printf("데이터 수정 실패\n");
    }
    else {
        printf("데이터 수정 완료\n");
    }

    OCIHandleFree(stmthp, OCI_HTYPE_STMT);
}

// 고객 검색
void select_data_by_customer_name(const char* customer_name_input) {
    OCIStmt* stmthp;
    OCIDefine* def1 = NULL, * def2 = NULL, * def3 = NULL, * def4 = NULL, * def5 = NULL, * def6 = NULL;
    OCIBind* bnd1 = NULL;

    char* select_sql = "SELECT TRANSACTION_ID, CUSTOMER_NAME, STOCK_NAME, TRANSACTION_TYPE, TRANSACTION_AMOUNT, TRANSACTION_PRICE FROM TRANSACTIONS WHERE CUSTOMER_NAME = :1";

    long transaction_id;
    char customer_name[MAX_CUSTOMER_NAME_LENGTH];
    char stock_name[MAX_STOCK_NAME_LENGTH];
    int transaction_type;
    long transaction_amount;
    double transaction_price;

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(stmthp, errhp, (text*)select_sql, strlen(select_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);

    // customer_name을 바인딩
    OCIBindByPos(stmthp, &bnd1, errhp, 1, (void*)customer_name_input, strlen(customer_name_input) + 1, SQLT_STR, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);

    OCIStmtExecute(svchp, stmthp, errhp, 0, 0, NULL, NULL, OCI_DEFAULT);

    // 컬럼 바인딩
    OCIDefineByPos(stmthp, &def1, errhp, 1, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def2, errhp, 2, customer_name, sizeof(customer_name), SQLT_STR, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def3, errhp, 3, stock_name, sizeof(stock_name), SQLT_STR, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def4, errhp, 4, &transaction_type, sizeof(transaction_type), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def5, errhp, 5, &transaction_amount, sizeof(transaction_amount), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def6, errhp, 6, &transaction_price, sizeof(transaction_price), SQLT_FLT, NULL, NULL, NULL, OCI_DEFAULT);

    printf("✅ '%s' 고객의 거래 내역:\n", customer_name_input);
    printf("------------------------------------------------------------------------\n");
    printf("| TRANSACTION_ID | CUSTOMER_NAME | STOCK_NAME | TRANSACTION_TYPE | TRANSACTION_AMOUNT | TRANSACTION_PRICE |\n");
    printf("------------------------------------------------------------------------\n");

    sword status;
    while ((status = OCIStmtFetch2(stmthp, errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT)) == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        printf("| %-15ld | %-10s | %-10s | %-15d | %-18ld | %-17.2f |\n", transaction_id, customer_name, stock_name, transaction_type, transaction_amount, transaction_price);
    }
    printf("------------------------------------------------------------\n");
}


// 데이터 삭제 함수
void delete_data_by_transaction_id(long transaction_id) {
    OCIStmt* stmthp;
    OCIBind* bnd1 = NULL;

    // 올바른 DELETE SQL 쿼리
    char* delete_sql = "DELETE FROM TRANSACTIONS WHERE TRANSACTION_ID = :1";

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);
    OCIStmtPrepare(stmthp, errhp, (text*)delete_sql, strlen(delete_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);

    // 바인딩: 삭제할 거래 ID 적용
    OCIBindByPos(stmthp, &bnd1, errhp, 1, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL, NULL, 0, NULL, OCI_DEFAULT);


    // SQL 실행 및 예외 처리
    if (OCIStmtExecute(svchp, stmthp, errhp, 1, 0, NULL, NULL, OCI_COMMIT_ON_SUCCESS) != OCI_SUCCESS) {
        check_error(errhp);
        printf("데이터 삭제 실패!\n");
    }
    else {
        printf("데이터 삭제 완료!\n");
    }

    OCIHandleFree(stmthp, OCI_HTYPE_STMT);
}


// 연결 종료 및 리소스 해제 함수
void disconnect_from_db() {
    // 자원 해제
    if (usrhp != NULL) {
        OCISessionEnd(svchp, errhp, usrhp, OCI_DEFAULT);
        OCIHandleFree(usrhp, OCI_HTYPE_SESSION);
    }
    
    if (srvhp != NULL) {
        OCIHandleFree(srvhp, OCI_HTYPE_SERVER);
    }
    
    if (svchp != NULL) {
        OCIHandleFree(svchp, OCI_HTYPE_SVCCTX);
    }
    
    if (errhp != NULL) {
        OCIHandleFree(errhp, OCI_HTYPE_ERROR);
    }
    
    if (envhp != NULL) {
        OCIHandleFree(envhp, OCI_HTYPE_ENV);
    }

    printf("✅ 연결 종료\n");
}

// DB종료 시 csv에 저장할 것들을 반환하는 함수
Transaction* get_data() {
    OCIStmt* stmthp;
    OCIDefine* def1 = NULL, * def2 = NULL, * def3 = NULL, * def4 = NULL, * def5 = NULL, * def6 = NULL;
    char* select_sql = "SELECT TRANSACTION_ID, CUSTOMER_NAME, STOCK_NAME, TRANSACTION_TYPE, TRANSACTION_AMOUNT, TRANSACTION_PRICE FROM TRANSACTIONS ORDER BY TRANSACTION_ID";
    long transaction_id;
    char customer_name[MAX_CUSTOMER_NAME_LENGTH];
    char stock_name[MAX_STOCK_NAME_LENGTH];
    int transaction_type;
    long transaction_amount;
    double transaction_price;

    OCIHandleAlloc(envhp, (void**)&stmthp, OCI_HTYPE_STMT, 0, NULL);

    OCIStmtPrepare(stmthp, errhp, (text*)select_sql, strlen(select_sql), OCI_NTV_SYNTAX, OCI_DEFAULT);
    OCIStmtExecute(svchp, stmthp, errhp, 0, 0, NULL, NULL, OCI_DEFAULT);

    OCIDefineByPos(stmthp, &def1, errhp, 1, &transaction_id, sizeof(transaction_id), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def2, errhp, 2, customer_name, sizeof(customer_name), SQLT_STR, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def3, errhp, 3, stock_name, sizeof(stock_name), SQLT_STR, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def4, errhp, 4, &transaction_type, sizeof(transaction_type), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def5, errhp, 5, &transaction_amount, sizeof(transaction_amount), SQLT_INT, NULL, NULL, NULL, OCI_DEFAULT);
    OCIDefineByPos(stmthp, &def6, errhp, 6, &transaction_price, sizeof(transaction_price), SQLT_FLT, NULL, NULL, NULL, OCI_DEFAULT);

    // Count the number of rows dynamically by fetching the data
    int count = 0;
    sword status;
    while ((status = OCIStmtFetch2(stmthp, errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT)) == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        count++;
    }

    // Check if count is valid
    if (count == 0) {
        printf("No data found in the database.\n");
        return NULL;
    }

    // Allocate memory for the result set dynamically based on the count
    Transaction* transactions = (Transaction*)calloc(count, sizeof(Transaction));
    if (transactions == NULL) {
        printf("Memory allocation failed.\n");
        return NULL;
    }

    // Reset the cursor and fetch data into the allocated memory
    OCIStmtExecute(svchp, stmthp, errhp, 0, 0, NULL, NULL, OCI_DEFAULT);
    int idx = 0;
    while ((status = OCIStmtFetch2(stmthp, errhp, 1, OCI_DEFAULT, 0, OCI_DEFAULT)) == OCI_SUCCESS || status == OCI_SUCCESS_WITH_INFO) {
        transactions[idx].transaction_id = transaction_id;
        snprintf(transactions[idx].customer_name, MAX_CUSTOMER_NAME_LENGTH, "%s", customer_name);
        snprintf(transactions[idx].stock_name, MAX_STOCK_NAME_LENGTH, "%s", stock_name);
        transactions[idx].transaction_type = transaction_type;
        transactions[idx].transaction_amount = transaction_amount;
        transactions[idx].transaction_price = transaction_price;
        idx++;
    }

    // Check if we fetched all rows
    if (idx != count) {
        printf("Warning: Fetched rows do not match the count.\n");
    }

    // .dat 파일 열기
    int row_count = count;
    FILE* file = fopen("stocks.dat", "w");
    if (file == NULL) {
        printf("파일을 열 수 없습니다.\n");
        free(transactions);
        return NULL;
    }

    // 거래 정보 작성 (CSV 대신 .dat 형식으로 작성)
    for (int i = 0; i < row_count; i++) {
        fprintf(file, "%ld  %s %s %s %ld %.2f\n",
            transactions[i].transaction_id,
            transactions[i].customer_name,
            transactions[i].stock_name,
            transactions[i].transaction_type == BUY ? "매수" : "매도",
            transactions[i].transaction_amount,
            transactions[i].transaction_price);
    }

    // 파일 닫기
    fclose(file);

    file = fopen("stocks.csv", "w");
    if (file == NULL) {
        printf("파일을 열 수 없습니다.\n");
        free(transactions);
        return NULL;
    }

    // 거래 정보 작성 (CSV 대신 .dat 형식으로 작성)
    for (int i = 0; i < row_count; i++) {
        fprintf(file, "%ld  %s %s %s %ld %.2f\n",
            transactions[i].transaction_id,
            transactions[i].customer_name,
            transactions[i].stock_name,
            transactions[i].transaction_type == BUY ? "매수" : "매도",
            transactions[i].transaction_amount,
            transactions[i].transaction_price);
    }

    // 파일 닫기
    fclose(file);


    // 메모리 해제
    free(transactions);
    printf(".dat 파일로 저장되었습니다.\n");

    // Return the result
    return transactions;
}
